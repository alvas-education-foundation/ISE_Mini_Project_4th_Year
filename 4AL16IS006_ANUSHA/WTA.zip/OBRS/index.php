<!DOCTYPE html>

<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>OBR</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		
	</head>
	<body class="landing">

		<!-- Header -->
			<header id="header">
				<h1><a href="index.php">BookMyBusTicket</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.php">Home</a></li>
						<li><a href="#about">About</a></li>
						<li><a href="index4.php">Users</a></li>
						<li><a href="recover/admin1.php">Admin</a></li>
						<li><a href="#contact">Developers</a></li>
					</ul>
				</nav>
			</header>

		<!-- Banner -->
			<section id="banner">
				<h2>Welcome to BookMyBusTicket</h2>
				<p>Quick Search <br> Online Bookings <br> Pay Online <br> Hassle Free Bus Booking</p>
				<ul class="actions">
					<li>
						<a href="#about" class="button big">Learn More</a>
					</li>
				</ul>
			</section>

		<!-- One -->
		<a name="about"></a>
			<section id="one" class="wrapper style1 align-center">
				<div class="container">
					<header>
						<h2>Book My Bus Ticket</h2>
						<p> <b>BookMyBusTicket is a online bus reservation system. <br>You can now choose your bus and your seat easily, have the tickets delivered to your mail and online payments. <br>Try BookMyBusTicket experience today.</b></p>

					</header>
					
				</div>
			</section>

		<!-- Two -->
			<section id="two" class="wrapper style2 align-center">
				<div class="container">
					<header>
						<h2>BookMyBusTicket</h2>
						<p>Book, Travel, Enjoy & Make Memories <br> "Pay Less Live Large"</p>
					</header>
					<div class="row">
						<section class="feature 6u 12u$(small)">
							<img class="image fit" src="images1/bus4.jpg" alt="" />
					
					</section>
						<section class="feature 6u$ 12u$(small)">
							<img class="image fit" src="images1/bus5.jpg" alt="" />
						</section>
						
					</div>
					<footer>
						<ul class="actions">
							<li>
								
							</li>
						</ul>
						<p> <b> Procedure Call <BR>	<style type="text/css">
  #proc_anu {
  all: initial;
  * {
    all: unset;
  }
}
</style>
<section class="proc_anu" id="proc_anu">
 
  <?php
include 'include.php';
$sqlproc= "CALL Get_all_users()";
$result=mysqli_query($connec,$sqlproc) or die(mysqli_error());

    

while($val=mysqli_fetch_array($result)) {
  print "<pre><br>";
  print_r($val);
}
?>
</section> </b></p>
					</footer>
				</div>
			</section>

<a name="contact"></a>
		<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<div class="row">
						<section class="4u 6u(medium) 12u$(small)">
							<h3>BoookMyTicket</h3>
							<ul class="alt">
								<li>Quick Search</li>
								<li>Online Bookings</li>
								<li>Pay Online</li>
								<li>Hassle Free Bus Booking</li>
								
							</ul>
						</section>
						<section class="4u 6u$(medium) 12u$(small)">
							<h3>Top Bus Routes</h3>
							<ul class="alt">
								<li>PKR - KTM</li>
								<li>KTM - CTN</li>
								<li>BTL - BIR</li>
								<li>DAR - PKR</li>
							</ul>
						</section>
					<section  class="4u 6u(medium) 12u$(small)">
						<table>
							<tr><th>Anusha</th>
							<th>Krithi k shetty</th></tr>
							<tr>
								<td>4AL16IS006</td>
								<td>4AL16IS023</td>
							</tr>
						</table>
					</section>
					</center>
					</div>
					<ul class="copyright">
						<li>&copy;2018. DBMS Mini Project. All rights reserved.</li>
					</ul>
				</div>
			</footer>

	</body>
</html>
