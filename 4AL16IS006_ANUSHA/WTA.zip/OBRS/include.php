<?php 
//$connec=@mysql_connect("localhost","root","kashi");
//$db=mysql_select_db("busnew");


$connec = mysqli_connect("localhost","root","","busnew");


// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>
