<?php
echo "REgistration done";
?>