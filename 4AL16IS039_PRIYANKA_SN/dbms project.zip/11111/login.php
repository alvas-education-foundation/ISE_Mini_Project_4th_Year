<html>
<head>
	<title>Welcome To Login</title>
	<link rel="style.css" type="text/css" href="style.css">
	<style type="text/css">
		body{
	background-image: url(img/login.jpg);
	background-repeat: no-repeat;
	background-size: 100%;
}#btn_b1 {
    background-color: #e7e7e7;
    border: none;
    color: black;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;

	</style>
</head>
<body>
	<center><b><font color="#800000" size="50" style="Times New Roman"> jewelery Store Database System</font></b></center><br><br><br><br>
	 <div id="main-wrapper">
	 	<form action="login.php" method="post">
	
	 		<center><b>User Name: <input class="inputvalues" type="text" placeholder="user name" name="name" size="35" required/></b><br><br><br>
	 		<b>Password: <input class="inputvalues" type="password" placeholder="password" name="pwdd" size="35" required/></b><br><br>
	 		<input type="submit" id="btn_b1" name="submit_btn" value="Login"><br><br>
	 	</center>
	 	</form>
	 </div>

<?php
$servername ="localhost";
$dbname="jewelery";
if(isset($_POST['submit_btn']))
{
	$username=$_POST["name"];
	$password=$_POST["pwdd"];
	if (($username=='priyanka' AND $password=='priyanka')) {

		$conn=mysqli_connect($servername,$username,$password,$dbname);
		header('location:next.php');
	}
else
	{
		echo '<script type="text/javascript"> alert("Invalid Credentials")</script>';
	}
}
?>

</body>
</html>