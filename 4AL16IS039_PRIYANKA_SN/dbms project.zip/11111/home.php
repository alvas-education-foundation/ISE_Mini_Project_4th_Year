<html>
<head>
<title>Welcome page</title>
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
	#btn_b1 {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
}
body{
	background-image: url(img/home1.jpg);
	background-repeat: no-repeat;
	background-size: 100%;
}
</style>
</head>
<body ><br><br><br><br>
<b><center><font color= "white" size="8" style="Arial" backgroud-color="blue">WELCOME TO JEWELERY MANAGEMENT DATABASE SYSTEM</font></center></b><br><br><br><br>
<center><a href="login.php"><button id="btn_b1"><font style="Serif">Goto Login</button></a></center>
</body>
</html>