<html>
<head>
<title>Add Customer Details</title>
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
	#btn_b1 {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
}
body{
	background-image: url(img/add.jpg);
	background-repeat: no-repeat;
	background-size: 100%;
}
</style>
</head>
<body ><br><b><center><font color="#0707F" size="5" style="Times New Roman"> 
		Add Customer Details</font></center></b> <br>
		<form action="addcus.php" method="post">
<div id="main-wrapper"><b>
Customer ID : <input class="inputvalues" type="text" name="cid" required/><br><br>
Customer Name : <input class="inputvalues" type="text" name="cname" required/><br><br>
Customer Address : <input class="inputvalues" type="text"  name="caddress" required/><br><br>
Customer Phone no: <input class="inputvalues" type="text" name="cphno" required/><br><br>
<center><input type="submit" id="submit_btn" name="submit_btn" value="Save"></b></center>
<?php
$servername = "localhost";
$username = "root";
$password="";
$dbname = "jewelery";


// Create connection
$conn = mysqli_connect($servername,$username,$password,$dbname);
// Check connection
if ($conn->connect_error)
{
echo "<script>alert('Invalid credentials');</script>";
} 
else if(isset($_POST['submit_btn']))
{
	  $cid =$_POST['cid'];
      $cname=$_POST['cname'];
      $caddress=$_POST['caddress'];
      $cphno=$_POST['cphno'];
      $sql = "insert into addcus values('$cid','$cname','$caddress','$cphno');";
      $result = $conn->query($sql);
     
      
  }


?>	
<center>

</div>	<br><br><br> 

</body>
</html>
