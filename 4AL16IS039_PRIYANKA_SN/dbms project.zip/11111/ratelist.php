<html>
<head>
<title> All rate Deatils </title>
<link rel="stylesheet" type="text/css" href="style1.css">
<h1><center><font color="#0707F" size="5" style="Times New Roman">All rate List</font></center><br></h1>
<style type="text/css">
    #btn_b1 {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
}
body{
    background-image: url(img/add.jpg);
    background-repeat: no-repeat;
    background-size: 100%;
}
</style>
</head>
<body >
	<center> <table width="500" cellpadding=5celspacing=5 border=1><tr><th> rate gold</th><th> </th><th> rate silver </th><th> rate platinum</th></tr>
<form>
<div id="main-wrapper">
<?php


$servername = "localhost";
$username = "root";
$password="";
$dbname = "jewelery";

// Create connection
$conn = mysqli_connect($servername,$username,$password,$dbname);
// Check connection
if ($conn->connect_error) {
echo "<script>alert('Invalid credentials');</script>";
} 

$sql = "SELECT * FROM addrate;";
$result = $conn->query($sql);

if ($result->num_rows > 0) 

  
     
    while($row = $result->fetch_assoc()):?>
     <tr>
     	<td><?php echo $row["rgold"];?></td>
     	<td><?php echo $row["rsilver"];?></td>
     	<td><?php echo $row["rplatinum"];?></td>     	
     </tr>
	
    <?php endwhile;?>
    </table>

</center>

<center><br><br>
<a href="home.php"><input type="button" id="submit_btn" value="Logout"></a>
		</form></center>
</div>	<br><br><br> 

</body>
</html>
