<html>
<head>
<title>Add Item Details</title>
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
	#btn_b1 {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
}
body{
	background-image: url(img/add.jpg);
	background-repeat: no-repeat;
	background-size: 100%;
}
</style>
</head>
<body ><br><b><center><font color="#0707F" size="5" style="Times New Roman"> Add Item Details</font></center></b> <br>
<form action="additem.php" method="post">
<div id="main-wrapper"><b>
Item ID:   <input class="inputvalues" type="text" name="iid" required/><br><br>
item weight:   <input class="inputvalues" type="text" name="iweight" required/><br><br>
item Type :     <input class="inputvalues" type="text"  name="itype" required/><br><br>
item category:     <input class="inputvalues" type="text"  name="icategory" required/><br><br>


<center><input type="submit" id="submit_btn" name="submit_btn" value="Save"></center></b>
<?php
$servername = "localhost";
$username = "root";
$password="";
$dbname = "jewelery";


// Create connection
$conn = mysqli_connect($servername,$username,$password,$dbname);
// Check connection
if ($conn->connect_error)
{
echo "<script>alert('Invalid credentials');</script>";
} 
else if(isset($_POST['submit_btn']))
{
	  $iid =$_POST['iid'];
      $iweight=$_POST['iweight'];
	$itype=$_POST['itype'];
$icategory=$_POST['icategory'];
   
      $sql = "insert into additem values('$iid','$iweight','$itype','$icategory');";
      $result = $conn->query($sql);
     
      
  }


?>	
<center>

</div>	<br><br><br> 

</body>
</html>
