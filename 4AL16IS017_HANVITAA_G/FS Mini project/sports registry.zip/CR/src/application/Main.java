package application;

import javafx.application.Application;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.DatePicker;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.scene.control.Toggle;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.swing.event.ChangeListener;

import java.io.*;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.time.format.DateTimeFormatter;

import javafx.scene.image.Image;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;

public class Main extends Application {

	static Stage MainWindow;
	static Scene Main,AddEvent,SearchEvent,ShowAll,UpdateEvent,DeleteEvent,register;
	int HashValue;
	static String EveFile = "sports.txt";
	static String TempFile = "Tempsports.txt";
	static String catefile = "category.txt";
	int confirmation = 0;
	String Temp;
	String Line;
	String T1,T2,T3;
	ArrayList<SampleController>StreamLoader = new ArrayList<SampleController>();
	private final static TableView<SampleController> tableView = new TableView<>();
	private final static ObservableList<SampleController> dataList = FXCollections.observableArrayList();
	static TableColumn columnF1=new TableColumn("Name");
	static TableColumn columnF2=new TableColumn("age");
	static TableColumn columnF3=new TableColumn("category");
	static TableColumn columnF4=new TableColumn("Type");
	static TableColumn columnF5=new TableColumn("Date");
	static TableColumn columnF6=new TableColumn("Time");
	static TableColumn columnF7=new TableColumn("place");
	//static TableColumn columnF8=new TableColumn("Venue");
	static ArrayList<String>HashList=new ArrayList<String>();
	static ArrayList<String>DateList=new ArrayList<String>();
	static ArrayList<String>TimeList=new ArrayList<String>();
	static ArrayList<String> category = new ArrayList<String>();
	static Label Header=new Label();
	static Label EmptySpace=new Label();
	String FFF;
	static Label msgs=new Label();


	static VBox vBox = new VBox();
	static GridPane BPSHA=new GridPane();

	static Label SuccessMsg=new Label("Saved Successfully");

	static Button RetButton=new Button("Return");


	public static void initTable()
	{
		DateList.clear();
		TimeList.clear();
		HashList.clear();

		BufferedReader br;

        try {
            br = new BufferedReader(new FileReader(EveFile));

            String line;
            while ((line = br.readLine()) != null) {
                String[] fields = line.split("#");

                DateList.add(fields[2].toUpperCase());
                TimeList.add(fields[3].toUpperCase());
                HashList.add(fields[4].toUpperCase());

            }

        } catch (Exception ex) {
            System.out.println("An Error Occured "+ex);
        }



	}

	public static void Reset()
	{
		msgs.setVisible(false);
		initTable();
	}
	public static void main(String[] args) {

		initTable();

		columnF1.setCellValueFactory(new PropertyValueFactory<>("f1"));


	    columnF2.setCellValueFactory(new PropertyValueFactory<>("f2"));


	    columnF3.setCellValueFactory(new PropertyValueFactory<>("f3"));


	    columnF4.setCellValueFactory(new PropertyValueFactory<>("f4"));
	    columnF5.setCellValueFactory(new PropertyValueFactory<>("f5"));
	    columnF6.setCellValueFactory(new PropertyValueFactory<>("f6"));
	    columnF7.setCellValueFactory(new PropertyValueFactory<>("f7"));

	    //columnF5.setCellValueFactory(new PropertyValueFactory<>("f5"));

	    columnF1.prefWidthProperty().bind(tableView.widthProperty().multiply(0.2));
	    columnF2.prefWidthProperty().bind(tableView.widthProperty().multiply(0.2));
	    columnF3.prefWidthProperty().bind(tableView.widthProperty().multiply(0.2));
	    columnF4.prefWidthProperty().bind(tableView.widthProperty().multiply(0.2));
	    columnF5.prefWidthProperty().bind(tableView.widthProperty().multiply(0.2));
	    columnF6.prefWidthProperty().bind(tableView.widthProperty().multiply(0.2));
	    columnF7.prefWidthProperty().bind(tableView.widthProperty().multiply(0.2));

	    tableView.setPrefSize(900, 450);
		tableView.getColumns().addAll(columnF1, columnF2, columnF3, columnF4, columnF5,columnF6,columnF7);
		msgs.setFont(Font.font("Verdana",FontWeight.BOLD,15));
		msgs.setTextFill(Color.RED);

		Header.setFont(Font.font("Verdana",15));
		Header.setTextFill(Color.BLUE);
		Header.setText("		");
		EmptySpace.setText("		");

	     Button ReTButton=new Button("Return");
	     ReTButton.setTextFill(Color.GREEN);
	     ReTButton.setOnAction(e->{
	    	 	Reset();
	        	MainWindow.setScene(Main);
	        });
	     Button DelButton=new Button("Delete");
	     DelButton.setTextFill(Color.RED);
	     DelButton.setOnAction(e->{
	    	 deleteEvent();
	    	 TableViewer();
	        });
			Button ModifyE = new Button("Modify");
			ModifyE.setTextFill(Color.BLUE);
			ModifyE.setOnAction(e->{MainWindow.setScene(UpdateEvent);
			});


	     ShowAll=new Scene(BPSHA, 800,550 );
	     HBox hbv=new HBox();
	     hbv.setSpacing(30);
	     hbv.getChildren().add(EmptySpace);
	     //hbv.getChildren().add(ModifyE);
	     hbv.getChildren().add(DelButton);
	     hbv.getChildren().add(ReTButton);

	     hbv.getChildren().add(msgs);
	     msgs.setVisible(false);

	     vBox.setSpacing(10);
	     vBox.getChildren().add(Header);
	     vBox.getChildren().add(tableView);
	     vBox.getChildren().add(hbv);


	     BPSHA.getChildren().add(vBox);
		launch(args);

	}

	public int AddtoFile(String Line)
	{
		try
		{
			Writer writer = new BufferedWriter(new OutputStreamWriter(
			        new FileOutputStream(EveFile, true), "UTF-8"));
			HashValue=Line.hashCode();
			writer.write(Line+"#"+HashValue+"\n");
			writer.close();
			initTable();
			return 1;
		}
		catch(Exception E)
		{
			return 0;
		}
	}
	public int AddtoFile2(String Line)
	{
		try
		{
			Writer writer = new BufferedWriter(new OutputStreamWriter(
			        new FileOutputStream(catefile, true), "UTF-8"));
			//HashValue=Line.hashCode();
			writer.write(Line+"\n");
			writer.close();
			//initTable();
			return 1;
		}
		catch(Exception E)
		{
			return 0;
		}
	}

	public void ShowAllEvents()
	{
		try (Stream<String> stream = Files.lines(Paths.get(EveFile))) {
	        stream.forEach(System.out::println);
	}
		catch( Exception E)
		{
			System.out.println("Error : Cannot Open File");

		}


	}
	@SuppressWarnings("unused")
	public static void deleteEvent()
	{
		SampleController DelItem = tableView.getSelectionModel().getSelectedItem();
		if(DelItem==null)
		{
			msgs.setText("Select a sportsman First");
			msgs.setVisible(true);
			return;
		}
		String DelT=DelItem.getF1()+"#"+DelItem.getF2()+"#"+DelItem.getF3()+"#"+DelItem.getF4()+"#"+DelItem.getF5()+"#"+DelItem.getF6()+"#"+DelItem.getF7()+"#"+DelItem.getF8();
		System.out.println("Selected sprtsman is : "+DelT);
		File Original = new File(EveFile);
		try{
				 File file = new File("Event.txt");
				   List<String> out = Files.lines(Original.toPath())
				                       .filter(line -> !line.contains(DelT))
				                       .collect(Collectors.toList());
				   Files.write(Original.toPath(), out, StandardOpenOption.WRITE, StandardOpenOption.TRUNCATE_EXISTING);
		}
		catch(Exception e)
		{
			System.out.println("\n\nAn Error Occured : "+e);
		}
		initTable();

	}
	public static void index()
	{
		category.clear();
		 String line;
		 try {
		        BufferedReader reader = new BufferedReader(new FileReader(catefile));
		        while((line=reader.readLine()) != null){
		            category.add(line);
		        }reader.close();
		    } catch (Exception e) {
		        e.printStackTrace();
		    }
	}
	public static void TableViewer() {
		tableView.getItems().clear();
		tableView.setItems(dataList);
		ScFileReader();
		Header.setText("			");
		MainWindow.setScene(ShowAll);
	}
	private static void ScFileReader() {
	    String FieldDelimiter = "#";
	    dataList.removeAll();
	    BufferedReader br;
	    try {
	        br = new BufferedReader(new FileReader(EveFile));
	        String line;
	        while ((line = br.readLine()) != null) {
	            String[] fields = line.split("#");
	            SampleController record = new SampleController(fields[0], fields[1], fields[2],fields[3],fields[4],
	            		fields[5],fields[6],fields[7]);
	            dataList.add(record);
	        }
	    } catch (FileNotFoundException ex) {
	    } catch (IOException ex) {
	    }
	}

	//User Interface
	@Override
	public void start(Stage mainstage) throws Exception {

		MainWindow = mainstage;
		MainWindow.setResizable(false);
		GridPane PB = new GridPane();
		HBox HB = new HBox();
		VBox VB = new VBox();
		HB.setPadding(new Insets(50, 50, 50, 50));
		HB.setSpacing(10);
		HB.setPrefSize(900,300);
		VB.setPadding(new Insets(15, 32, 55, 12));
		VB.setPrefSize(900, 400);
		VB.setSpacing(30);
		initTable();
		//FIRST SCREEN
		Label WelcomeTitle=new Label("SPORTS REGISTRY ");
		WelcomeTitle.setFont(Font.font("Times New Roman", FontWeight.BOLD,FontPosture.REGULAR, 30));
		WelcomeTitle.setTextFill(Color.RED);
//main screen add button
		Button AddC=new Button("ADMIN");
		AddC.setPadding(new Insets(10,10,10,10));
		AddC.setPrefSize(300,30);
		AddC.setOnAction(e->{MainWindow.setScene(AddEvent);
		SuccessMsg.setVisible(false);
		});
		//REGISTER BUTTON
		Button RegC=new Button("REGISTER");
		RegC.setPadding(new Insets(10,10,10,10));
		RegC.setPrefSize(300,30);
		RegC.setOnAction(e->{MainWindow.setScene(register);
		SuccessMsg.setVisible(false);
		});
//main screen search button
		Button SearchC=new Button("SEARCH");
		SearchC.setPadding(new Insets(10,10,10,10));
		SearchC.setPrefSize(300,30);
		SearchC.setOnAction(e->{MainWindow.setScene(SearchEvent);
		});

//main screen view all button
		Button ViewAC=new Button("View All");
		ViewAC.setPadding(new Insets(10,10,10,10));
		ViewAC.setPrefSize(300,30);
		ViewAC.setOnAction(e->{MainWindow.setScene(ShowAll);
		TableViewer();
		ShowAllEvents();
		});

//main screen update button

		HB.getChildren().addAll(WelcomeTitle);
		HB.setPadding(new Insets(50,70,20,250));
		VB.getChildren().addAll(AddC,RegC,SearchC,ViewAC);
		VB.setPadding(new Insets(20,20,20,250));
		PB.add(HB,0,1);
		PB.add(VB,0,2);
		Main=new Scene(PB,800,550);

	MainWindow.setScene(Main);
	MainWindow.setTitle("FS Mini Project");
	MainWindow.show();
/*-------------------------------------------------------------------------------------------------------------------*/
	//create event screen
	GridPane BP1=new GridPane();
	HBox HB1=new HBox();
	HBox HB11=new HBox();
	HBox HB12=new HBox();
	HBox HB121=new HBox();
	HBox HB111=new HBox();
	HBox HB112=new HBox();
	HBox HB113=new HBox();

	 HB1.setPadding(new Insets(25, 25, 15, 12));
	 HB1.setSpacing(20);

	 HB11.setPadding(new Insets(55, 85, 85, 100));
	 HB11.setSpacing(20);
	 HB12.setPadding(new Insets(25, 25, 15, 12));
	 HB12.setSpacing(20);

	 HB121.setPadding(new Insets(25, 25, 15, 102));
	 HB121.setSpacing(20);
	 HB111.setPadding(new Insets(25, 25, 15, 12));
	 HB111.setSpacing(20);

	 HB112.setPadding(new Insets(25, 25, 15, 12));
	 HB112.setSpacing(25);

	 HB113.setPadding(new Insets(25, 25, 15, 12));
	 HB113.setSpacing(25);

	BP1.setPadding(new Insets(10,10,10,10));

	SuccessMsg.setFont(Font.font("Verdana",FontWeight.BOLD,15));
	SuccessMsg.setTextFill(Color.GREEN);
	SuccessMsg.setVisible(false);

	Label WelcomeTitle1=new Label("add a sports category");
	WelcomeTitle1.setFont(Font.font("Times New Roman", FontWeight.BOLD,FontPosture.REGULAR, 20));
	WelcomeTitle1.setTextFill(Color.RED);

	Label Heading1=new Label("Fill all the Fields :");
	Heading1.setFont(Font.font("Verdana",FontWeight.BOLD,15));
	String cat[] = {"Men","Women"};
	Label EName=new Label("Category :");
	ComboBox ENameF=new ComboBox(FXCollections.observableArrayList(cat));
	ENameF.setPrefWidth(200);
	ENameF.setPromptText("Default");
	ENameF.setOnMouseClicked(e->SuccessMsg.setVisible(false));

	Label EType=new Label("Type :");
	TextField ETypeF=new TextField();
	ETypeF.setPrefWidth(200);
	ETypeF.setPromptText("Ex: Race(100m)");
	ETypeF.setOnMouseClicked(e->SuccessMsg.setVisible(false));

	DatePicker EDateF = new DatePicker();
	Label EDateFr=new Label("Date  :");
	EDateF.setPrefWidth(200);
	EDateF.setOnMouseClicked(e->SuccessMsg.setVisible(false));
	Label ETimeFr=new Label("Time  :");

	TextField ETimeS=new TextField();
	ETimeS.setPrefWidth(200);
	ETimeS.setPromptText("HH:MM AM/PM");
	ETimeS.setOnMouseClicked(e->SuccessMsg.setVisible(false));

	Label ELoc=new Label("Place :");
	TextField ELocF=new TextField();
	ELocF.setPrefWidth(200);
	ELocF.setPromptText("Place");
	ELocF.setOnMouseClicked(e->SuccessMsg.setVisible(false));

	Button Save = new Button("Add");
	Save.setTextFill(Color.BLUEVIOLET);

	Save.setOnAction(e->{
		if((ENameF.getWidth()>0)&&(ETypeF.getWidth()>0)&&(EDateF.getWidth()>0)&&(ETimeS.getLength()>0)&&(ELocF.getLength()>0))
		{
		Temp=(String) ENameF.getValue();
		if(Temp.length()>=2)
		{Temp=ETypeF.getPromptText();
		if(Temp!="EvenType")
		{
		Temp=ENameF.getValue()+"#"+ETypeF.getText()+"#"+EDateF.getValue()+"#"+ETimeS.getText()+"#"+ELocF.getText();
		if(DuplicateChecker(Temp)==0)
		{
		confirmation=AddtoFile2(Temp);
		if(confirmation==1)
		{
			//index();
			SuccessMsg.setText("Successfull");
			SuccessMsg.setTextFill(Color.GREEN);
			SuccessMsg.setVisible(true);
			ENameF.setPromptText("");
			ETypeF.setPromptText("");
			EDateF.setPromptText("");
			ETimeS.setText("");
			ELocF.setText("");
		}
		else
			System.out.println("ERROR - Adding to the File..!");
		}
	}else
	{
		SuccessMsg.setText("Select category");
		SuccessMsg.setTextFill(Color.RED);
		SuccessMsg.setVisible(true);
	}
		}
		else
		{
			SuccessMsg.setText("Please enter type");
			SuccessMsg.setTextFill(Color.RED);
			SuccessMsg.setVisible(true);
		}


		}
	else
	{
		SuccessMsg.setText("Fill all details.");
		SuccessMsg.setTextFill(Color.RED);
		SuccessMsg.setVisible(true);
		}
	});
	Button Cancel=new Button("Cancel");
	Cancel.setTextFill(Color.GREEN);

	Cancel.setOnAction(e->{
		Reset();
		MainWindow.setScene(Main);
		index();
	});

	HB1.getChildren().addAll(WelcomeTitle1);
	HB12.getChildren().addAll(Heading1);
	HB111.getChildren().addAll(EName,ENameF,EType,ETypeF);
	HB112.getChildren().addAll(EDateFr,EDateF,ETimeFr,ETimeS);
	HB121.getChildren().addAll(ELoc,ELocF);
	HB11.getChildren().addAll(Save,Cancel,SuccessMsg);
	HB11.setSpacing(100);

	BP1.add(HB1,0,1);
	BP1.add(HB12,0,2);
	BP1.add(HB111,0,3);
	BP1.add(HB112,0,4);
	BP1.add(HB113,0,5);
	BP1.add(HB121,0,6);
	BP1.add(HB11,0,7);

	AddEvent=new Scene(BP1,800,550);
/*---------------------------------------------------------------------------------*/
	//registration screen

	GridPane BP5 = new GridPane();
	HBox HB5=new HBox();
	HBox HB52=new HBox();
	HBox HB53 = new HBox();
	 HB5.setPadding(new Insets(25, 25, 15, 12));
	 HB5.setSpacing(10);
	 HB52.setPadding(new Insets(25, 25, 15, 12));
	 HB52.setSpacing(10);
	 HB53.setPadding(new Insets(25, 25, 15, 12));
	 HB53.setSpacing(10);


	 	index();
		Label SName=new Label("Category :");
		ComboBox SNameF=new ComboBox(FXCollections.observableArrayList(category));
		SNameF.setPrefWidth(200);
		SNameF.setPromptText("Default");
		SNameF.setOnMouseClicked(e->{SuccessMsg.setVisible(false);});

		Label ES=new Label("  Name : ");
		TextField ESF=new TextField();
		ESF.setPrefWidth(200);
		ESF.setPromptText("Name");
		ESF.setOnMouseClicked(e->SuccessMsg.setVisible(false));
		Label EA=new Label(" Age : ");
		TextField EAF=new TextField();
		EAF.setPrefWidth(200);
		EAF.setPromptText("Age");
		EAF.setOnMouseClicked(e->SuccessMsg.setVisible(false));
		Button Save5 = new Button("Register");
		Save5.setTextFill(Color.BLUEVIOLET);
		Save5.setOnAction(e->{
			if((SNameF.getWidth()>0)&&(ESF.getLength()>0)&&(EAF.getLength()>0))
			{
			Temp=ESF.getText();
			if(Temp.length()>=5)
			{Temp=EAF.getText();
			if(Temp != null)
			{
			Temp=ESF.getText()+"#"+EAF.getText()+"#"+SNameF.getValue();
			if(DuplicateChecker(Temp)==0)
			{
			confirmation=AddtoFile(Temp);
			if(confirmation==1)
			{
				SuccessMsg.setText("Successfull");
				SuccessMsg.setTextFill(Color.GREEN);
				SuccessMsg.setVisible(true);
				EAF.setPromptText("");
				ESF.setPromptText("");
				ENameF.setPromptText("");
			}
			else
				System.out.println("ERROR - Adding to the File..!");
			}
		}else
		{
			SuccessMsg.setText("Select category");
			SuccessMsg.setTextFill(Color.RED);
			SuccessMsg.setVisible(true);
		}
			}
			else
			{
				SuccessMsg.setText("enter name");
				SuccessMsg.setTextFill(Color.RED);
				SuccessMsg.setVisible(true);
			}


			}
		else
		{
			SuccessMsg.setText("Fill all details.");
			SuccessMsg.setTextFill(Color.RED);
			SuccessMsg.setVisible(true);
			}
		});
		Button Cancel5=new Button("Cancel");
		Cancel5.setTextFill(Color.GREEN);

		Cancel5.setOnAction(e->{
			Reset();
			MainWindow.setScene(Main);
		});

		HB5.getChildren().addAll(SName,SNameF);
		HB52.getChildren().addAll(ES,ESF,EA,EAF);
		HB53.getChildren().addAll(Save5,Cancel5,SuccessMsg);
		BP5.add(HB5,0,1);
		BP5.add(HB52, 0, 2);
		BP5.add(HB53,0,5);

		register=new Scene(BP5,800,550);


/*--------------------------------------------------------------------------------*/
	//screen to search

	GridPane BP2=new GridPane();
	HBox HB2=new HBox();
	HBox HB22=new HBox();
	HBox HB21=new HBox();
	HBox HB23= new HBox();
	 HB2.setPadding(new Insets(25, 25, 15, 12));
	 HB2.setSpacing(10);

	 HB22.setPadding(new Insets(25, 25, 15, 12));
	 HB22.setSpacing(10);
	 HB21.setPadding(new Insets(25, 25, 15, 12));
	 HB21.setSpacing(10);
	 HB23.setPadding(new Insets(55, 45, 25, 280));
	 HB23.setSpacing(80);

		SuccessMsg.setFont(Font.font("Verdana",FontWeight.BOLD,15));
		SuccessMsg.setTextFill(Color.GREEN);
		SuccessMsg.setVisible(false);

		Label WelcomeTitle2=new Label("Search for a Event in File");
		WelcomeTitle2.setFont(Font.font("Times New Roman", FontWeight.BOLD,FontPosture.REGULAR, 20));
		WelcomeTitle2.setTextFill(Color.CADETBLUE);

		Label ESearch=new Label("Name :");
		TextField ESearchF=new TextField();
		ESearchF.setPrefWidth(150);
		ESearchF.setPromptText("Name");
		ESearchF.setOnMouseClicked(e->SuccessMsg.setVisible(false));


		DatePicker ESearchFD = new DatePicker();
		Label ESearchD=new Label("Date :");
		ESearchFD.setPrefWidth(150);
		ESearchFD.setOnMouseClicked(e->SuccessMsg.setVisible(false));
		Label ESearchL=new Label("Place:");
		TextField ESearchFL=new TextField();
		ESearchFL.setPrefWidth(150);
		ESearchFL.setPromptText("Place");
		ESearchFL.setOnMouseClicked(e->SuccessMsg.setVisible(false));

		Button Search = new Button("Search");
		Search.setTextFill(Color.BLUEVIOLET);

		Search.setOnAction(e->{
			if(ESearchF.getText().length()>=3)
			{
				tableView.getItems().clear();
				SearchFile(ESearchF.getText());
				MainWindow.setScene(ShowAll);
			}
			else if(ESearchFL.getText().length()>=3)
			{
				tableView.getItems().clear();
				SearchFile(ESearchFL.getText());
				MainWindow.setScene(ShowAll);
			}

			else if(ESearchFD.getValue() != null)
			{
				String date=ESearchFD.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
				tableView.getItems().clear();
				SearchFile(date);
				MainWindow.setScene(ShowAll);

			}
			else if(ESearchF.getText().length()>=1)
			{
				ESearchF.setPromptText("Too Short to Search...!!");
				msgs.setText("Too Short to Search...!");
				msgs.setVisible(true);
			}
			else
			{
				ESearchF.setPromptText("Enter Something Here First...!");
				msgs.setText("Enter Something to Search...!");
				msgs.setVisible(true);
			}
		});
		Button Cancel1=new Button("Return");
		Cancel.setTextFill(Color.GREEN);

		Cancel1.setOnAction(e->{
			Reset();
			MainWindow.setScene(Main);
		});

		HB2.getChildren().addAll(WelcomeTitle2);
		HB21.getChildren().addAll(ESearch,ESearchF,ESearchD,ESearchFD,ESearchL,ESearchFL);
		HB23.getChildren().addAll(Search,Cancel1);
		BP2.add(HB21, 0, 3);
		BP2.add(HB22, 0, 2);
		BP2.add(HB2, 0, 1);
		BP2.add(HB23, 0, 4);
		SearchEvent=new Scene(BP2,800,550);
	}

	public static int DuplicateChecker(String NE)
	{
		initTable();
		String[] Sport=NE.split("#");
		String HS=Integer.toString(NE.hashCode());


		if(HashList.contains(HS))
		{
			SuccessMsg.setText("Already Registered");
			SuccessMsg.setVisible(true);
			return 1;
		}
		else
		return 0;
	}
	public String SearchFile(String Item)
	{

		 tableView.getItems().clear();

		 String[] Items = Item.split(" ");
		 String[] LineItems;
		 boolean Flag;

		try {
			BufferedReader bb=new BufferedReader(new FileReader(EveFile));
			Temp="";
			 tableView.getItems().clear();
			while((Line=bb.readLine())!=null)
			{
				Flag=false;
				T1=Item;
				T1=T1.toUpperCase();
				T2=Line;
				T2=T2.toUpperCase();
				LineItems=Line.split("#");

				for (String TX : LineItems)
				{
					TX=TX.toUpperCase();
					for(String FT:Items)
					{
						FT=FT.toUpperCase();
						if(TX.startsWith(FT))
				{

					String[] fields = Line.split("#");


					SampleController record = new SampleController(fields[0], fields[1], fields[2],fields[3],fields[4],fields[5],fields[6],fields[7]);
	                dataList.add(record);

	                Flag=true;

				}
						if(Flag==true)
						{
							break;
						}
				}
					if(Flag==true)
					break;
					}
			}

			Header.setText(" Search Results ");
			tableView.setItems(dataList);
			bb.close();

			if(Temp.length()>0)
				return Temp;
		}

		catch(Exception e)
		{
			System.out.println("Error in File Access -exception Occured \n"+e);
		}

		return "The Item : "+Item+" not Found in the List";
	}

}
