/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package attack_prevention;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * author Mindsoft
 */


public class SpecialCharacters
{
public static void main( String[] args ) throws IOException
{

String string = "ashzxcvbnmasdfghjklopiuytrewqASHWINI00675>";
Pattern pattern = Pattern.compile( "[^a-zA-Z0-9*]" );
Matcher matcher = pattern.matcher( string );

System.out.println(matcher.find());
String str = matcher.replaceAll( "F" );
System.out.print( str );
}
}
