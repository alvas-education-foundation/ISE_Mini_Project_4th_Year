package rest;


import java.awt.*;

import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;


import javax.swing.border.EmptyBorder;


public class SongDataSwing
{
 JFrame mainF,addF,viewF,deleteF,searchF,updateF,sortF;
 Container mainMenu,addMenu,viewMenu,deleteMenu,searchMenu,updateMenu,sortMenu;
 JPanel titlepan,mainMenuSelectP,addMenuSelectP,addMenuViewP,viewMenuViewP,deleteMenuSelectP,deleteMenuViewP,searchMenuSelectP,searchMenuViewP,updateMenuSelectP,updateMenuViewP,delettitle1;
 JButton b1,b2,b3,b4,b5,addMBtn,addBackB,viewBackB,deleteMBtn,deleteBackB,searchb1,searchb2,searchBackB,searchNameBtn,searchQualityBtn,searchPrizeBtn,searchMBtn,updateMBtn,updateBackB,updateSelectTraceBtn;  
 JLabel title,addIDL,addNameL,addPrizeL,addQualityL,addIDnoL,addStatusL,viewtitle;
 JLabel deleteIDL,deleteStatusL;
 JLabel searchNameL,searchPrizeL,searchPrize2L,searchQualityL;
 JLabel updateIDL,updateNameL,updatePrizeL,updateQualityL,updateStatusL, deletetitle;
 
 JTextField addMTextFID,addMTextFName,addMTextFPrize;
 JTextField deleteMTextFID;
 JTextField searchMTextFName,searchMTextFsec,searchMTextFename,searchMTextFedes;
 JTextField updateMTextFID,updateMTextFName,updateMTextFPrize;
 
 JComboBox mainMComboBox,searchMComboBox,searchMComboBQuality,addMComboBQuality,updateMComboBQuality;
 JTextArea mainMTextA,addMTextA,viewMTextA,deleteMTextA,searchMTextAForView,searchMTextAForResult,updateMTextAForView,updateMTextAForResult,sortMTextAForResult;
 String ID, name, Prize, SorN, Quality;
 String IDView, nameView, PrizeView, SorNView, IDnoView;
 String IDDelView, nameDelView, PrizeDelView, SorNDelView, IDnoDelView;
 String IDSort, nameSort, PrizeSort, SorNSort, IDnoSort;
 String IDDelete, nameDelete, PrizeDelete, SorNDelete, IDnoDelete;
 String nameSearchSel,nameSearchSe2, PrizeSearchSel, SorNSearchSel;
 String newNameUpdate, newQualityUpdate, splittUpdate, newPrizeUpdate, recordUpdate1, IDUpdate1,IDUpdate2nd,recordUpdate2,choice;
 String buffer;
 long pos_array[]=new long[1000];
 String primary_array[]=new String[1000];
 String secondary_array[]=new String[1000];
 long s_pos_array[]=new long[1000];
 JLabel delIDV,delNameV,delPrizeV,delQualityV;
 String delValidationID,delValidationName,delValidationPrize,delValidationQuality;
 //--ValUpdate
SongDataSwing()
{
	  mainF=new JFrame("Main Menu");
	  addF=new JFrame("Add Menu");
	  viewF=new JFrame("View All Menu");
	  deleteF=new JFrame("Delete Menu");
	  searchF=new JFrame("Search Menu");
	  updateF=new JFrame("Update Menu");
	  sortF=new JFrame("Sort Menu");
	//--Main Menu Container
	  {
		  mainMenu=mainF.getContentPane();
		   mainMenu.setBackground(Color.white);
		   mainMenu.setVisible(true);
		   
		   addMenu=addF.getContentPane();
		   addMenu.setBackground(Color.white);
		   addMenu.setVisible(true);
		   
		   viewMenu=viewF.getContentPane();
		   viewMenu.setBackground(Color.white);
		   viewMenu.setVisible(true);
		   
		   titlepan=new JPanel();
		   titlepan.setBounds(200,150,1000,100);
		   titlepan.setBackground(Color.white);
		   
		   mainMenuSelectP=new JPanel();
		   mainMenuSelectP.setBounds(530,265,400,180);
		   mainMenuSelectP.setBackground(Color.white);
		   
		   addMenuSelectP=new JPanel();
		   addMenuSelectP.setBounds(500,100,340,340);
		   addMenuSelectP.setLayout(new BoxLayout(addMenuSelectP,BoxLayout.PAGE_AXIS));
		   addMenuSelectP.setBorder(new EmptyBorder(new Insets(50, 100,50, 100)));
		   
		   
		   
		   viewMenuViewP=new JPanel();
		   viewMenuViewP.setBounds(350,80,720,420);
		   viewMenuViewP.setBackground(Color.white);

		   //addMenuSelectP.setBorder(BorderFactory.createEmptyBorder(0,30,10,10));
		   addMenuSelectP.setBackground(Color.white);
		   
		   addMenuViewP=new JPanel();
		   addMenuViewP.setBounds(500,450,340,100);
		   addMenuViewP.setBackground(Color.white);
		   
		   deleteMenu=deleteF.getContentPane();
		   deleteMenu.setBackground(Color.white);
		   deleteMenu.setVisible(true);
		   
		   
		   
		   deleteMenuSelectP=new JPanel();
		   deleteMenuSelectP.setBounds(600,475,200,80);
		   deleteMenuSelectP.setBackground(Color.white);
		   
		   deleteMenuViewP=new JPanel();
		   deleteMenuViewP.setBounds(350,150,720,370);
		   deleteMenuViewP.setBackground(Color.white);
		   
		   searchMenu=searchF.getContentPane();
		   searchMenu.setBackground(Color.white);
		   searchMenu.setVisible(true);
		   
		   //--Search Menu Panel
		   searchMenuSelectP=new JPanel();
		   searchMenuSelectP.setBounds(100,100,400,400);
		   searchMenuSelectP.setBackground(Color.white);
		   
		   searchMenuViewP=new JPanel();
		   searchMenuViewP.setBounds(600,100,650,400);
		   searchMenuViewP.setBackground(Color.white);
		   
		 //--Update Menu Container
		   updateMenu=updateF.getContentPane();
		   updateMenu.setBackground(Color.white);
		   updateMenu.setVisible(true);
		   
		   updateMenuSelectP=new JPanel();
		   updateMenuSelectP.setBounds(500,10,200,350);
		   updateMenuSelectP.setBackground(Color.white);
		   
		   updateMenuViewP=new JPanel();
		   updateMenuViewP.setBounds(750,10,200,200);
		   updateMenuViewP.setBackground(Color.white);

		   
	  }
	  {
		  
		   //add menu view
			   //--------------------------------------------------------------------------
			   //---
			   
			   addIDL=new JLabel("ID");
			   addIDL.setBounds(100,0,40,20);
			   
			   addMTextFID=new JTextField();
			   addMTextFID.setPreferredSize(new Dimension(60,20));
			   
			   //---
			   
			   addNameL=new JLabel("Name ");
			   addNameL.setPreferredSize(new Dimension(40,20));
			   
			   addMTextFName=new JTextField();
			   addMTextFName.setPreferredSize(new Dimension(110,20));
			   
			   //---
			   
			   addPrizeL=new JLabel("Singer ");
			   addPrizeL.setPreferredSize(new Dimension(40,20));
			   
			   addMTextFPrize=new JTextField();
			   addMTextFPrize.setPreferredSize(new Dimension(110,20));
			   
			   //---
			   
			   addQualityL=new JLabel("Genre ");
			   addQualityL.setPreferredSize(new Dimension(50,20));
			   
			   String selectQualityAdd[]={"Select Genre","Blues","Classical","Country","Folk","HipHop","Instrumeental","Melody","Pop","Rap","Rock"};
			   addMComboBQuality=new JComboBox(selectQualityAdd);
			   addMComboBQuality.setPreferredSize(new Dimension(110,20));
			   addMBtn=new JButton("Save");
			   addMBtn.setPreferredSize(new Dimension(80,20));
			   
			   addBackB=new JButton("Back");
			   addBackB.setPreferredSize(new Dimension(80,20));
			   addMTextA=new JTextArea();
			   addMTextA.setPreferredSize(new Dimension(170,80));
			   addMTextA.setEditable(false);
	  }
	
	  {//view menu view
		   //---
		   
		  viewtitle=new JLabel("       ALL RECORDS IN FILE");
		  viewtitle.setPreferredSize(new Dimension(300,30));
		  Font font = new Font("Times New Roman", Font.ITALIC,20);
		  viewtitle.setFont(font);
		  
		   viewBackB=new JButton("Back");
		   viewBackB.setPreferredSize(new Dimension(80,20));
		   
		   viewMTextA=new JTextArea(20, 60);
		   viewMTextA.setPreferredSize(new Dimension(700,650));
		   viewMTextA.setEditable(false);
		   
		   //---
		   //----------------------------------------------------------------
		   JScrollPane scrollView = new JScrollPane(viewMTextA,
		   JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		   //----------------------------------------------------------------
		   
		   viewMenuViewP.add(viewtitle,BorderLayout.CENTER);
		   viewMenuViewP.add(scrollView,BorderLayout.CENTER);
		   viewMenuViewP.add(viewBackB,BorderLayout.NORTH);
		 //  viewMenuViewP.add(viewMTextA,BorderLayout.SOUTH);
		   
		   
		  }
	  {//delete menu view
		  deletetitle=new JLabel("       ALL RECORDS IN FILE");
		  deletetitle.setPreferredSize(new Dimension(300,30));
		  Font font = new Font("Times New Roman", Font.ITALIC,20);
		  deletetitle.setFont(font);
		  
		   deleteIDL=new JLabel("ID: ");
		   deleteIDL.setForeground(Color.white);
		   deleteIDL.setPreferredSize(new Dimension(20,20));
		   
		   deleteMTextFID=new JTextField();
		   deleteMTextFID.setPreferredSize(new Dimension(110,20));
		   
		   deleteMBtn=new JButton("Delete");
		   deleteMBtn.setPreferredSize(new Dimension(80,20));
		   
		   deleteStatusL=new JLabel("---Status of Delete---");
		   deleteStatusL.setPreferredSize(new Dimension(170,20));
		   
		   deleteBackB=new JButton("Back");
		   deleteBackB.setPreferredSize(new Dimension(80,20));
		   
		   deleteMTextA=new JTextArea(15, 60);
		   deleteMTextA.setPreferredSize(new Dimension(700,430));
		   deleteMTextA.setEditable(false);
		  
		  
		  JScrollPane scrollDelete = new JScrollPane(deleteMTextA,
		   JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		  
		  //----------------------------------------------------------------
		  deleteMenuSelectP.add(deleteIDL,BorderLayout.NORTH);
		   deleteMenuSelectP.add(deleteMTextFID,BorderLayout.NORTH);
		   deleteMenuSelectP.add(deleteMBtn,BorderLayout.CENTER);
		   deleteMenuSelectP.add(deleteBackB,BorderLayout.CENTER);
		   deleteMenuSelectP.add(deleteStatusL,BorderLayout.SOUTH);
		   
		   deleteMenuViewP.add(deletetitle,BorderLayout.CENTER);
		   deleteMenuViewP.add(scrollDelete,BorderLayout.CENTER);
		  
		  }
	  {//Search menu view
		  
		  searchb1=new JButton("  SEARCH BY SONG            ");
		  searchb1.setPreferredSize(new Dimension(300,30));
		  Font font1 = new Font("TIMES NEW ROMAN",Font.ITALIC, 14);
		  //searchb1.setSize(200,100);
		  searchb1.setFont(font1);
		  searchb1.setBackground(Color.white);   
		  searchMenuSelectP.add(searchb1,BorderLayout.NORTH);
		  
		  searchb2=new JButton("  SEARCH BY SONG & SINGER    ");
		  searchb2.setPreferredSize(new Dimension(300,30));
		  Font font2 = new Font("TIMES NEW ROMAN",Font.ITALIC, 14);
		  //searchb1.setSize(200,100);
		  searchb2.setFont(font2);
		  searchb2.setBackground(Color.white);   
		  searchMenuSelectP.add(searchb2,BorderLayout.NORTH);
		  
		  
		  searchNameL=new JLabel("Song_Name: ");
		  searchNameL.setPreferredSize(new Dimension(105,40));
		   
		  searchMTextFName=new JTextField();
		  searchMTextFName.setPreferredSize(new Dimension(200,25));
		  
		  searchNameBtn=new JButton("select");
		  searchNameBtn.setPreferredSize(new Dimension(210,20));
		  //----------------------------------------------------------------
		  searchPrizeL=new JLabel("Song_name & Singer:");
		  searchPrizeL.setPreferredSize(new Dimension(190,40));
		   
		  searchMTextFename=new JTextField();
		  searchMTextFename.setPreferredSize(new Dimension(80,20));
		  
		  searchMTextFedes=new JTextField();
		  searchMTextFedes.setPreferredSize(new Dimension(80,20));
		  
		  searchPrizeBtn=new JButton("select");
		  searchPrizeBtn.setPreferredSize(new Dimension(210,20));
		  

		  searchBackB=new JButton("BACK");
		  searchBackB.setPreferredSize(new Dimension(300,30));
		  Font font3 = new Font("TIMES NEW ROMAN",Font.ITALIC, 14);
		  //searchb1.setSize(200,100);
		  searchBackB.setFont(font3);
		  searchBackB.setBackground(Color.white);
		  //----------------------------------------------------------------
		
		  //----------------------------------------------------------------
		  
		   searchMTextAForResult=new JTextArea(15, 50);
		   searchMTextAForResult.setPreferredSize(new Dimension(100,100));
		   searchMTextAForResult.setEditable(false);
		   
		   //---
		   //----------------------------------------------------------------
		   JScrollPane scrollSearch = new JScrollPane(searchMTextAForResult,
		   JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		  
		  //---------------------------------- Display ------------------------------
		  
		 
		  searchMenuSelectP.add(searchBackB,BorderLayout.SOUTH);
		  
		  searchMenuSelectP.add(searchNameL,BorderLayout.NORTH);
		  searchMenuSelectP.add(searchMTextFName,BorderLayout.NORTH);
		  searchMenuSelectP.add(searchNameBtn,BorderLayout.NORTH);
		  
		  searchMenuSelectP.add(searchPrizeL,BorderLayout.CENTER);
		  searchMenuSelectP.add(searchMTextFename,BorderLayout.CENTER);
		  searchMenuSelectP.add(searchMTextFedes,BorderLayout.CENTER);
		  searchMenuSelectP.add(searchPrizeBtn,BorderLayout.CENTER);
		  searchMenuViewP.add(scrollSearch,BorderLayout.CENTER);
		  searchNameL.setVisible(false);
          searchMTextFName.setVisible(false);
          searchNameBtn.setVisible(false);
          
          searchPrizeL.setVisible(false);
          searchMTextFename.setVisible(false);
          searchMTextFedes.setVisible(false);
          searchPrizeBtn.setVisible(false);
		  //-------------
		  
	
		  
		  //searchMenuViewP.add(scrollSearch,BorderLayout.CENTER);

		  //----------------------------------------------------------------
		  
		  }
	  {//Update menu view
		   //----------------------------------------------------------------
		   //---
		   updateIDL=new JLabel("ID: ");
		   updateIDL.setPreferredSize(new Dimension(20,20));
		   
		   updateMTextFID=new JTextField();
		   updateMTextFID.setPreferredSize(new Dimension(110,20));
		   
		   //---
		   updateSelectTraceBtn=new JButton("Select");
		   updateSelectTraceBtn.setPreferredSize(new Dimension(80,20));
		   //---
		   updateMTextAForView=new JTextArea("Tracing the details\nID\nName\ndesignation\nsex\nIDno");
		   updateMTextAForView.setPreferredSize(new Dimension(170,150));
		   updateMTextAForView.setEditable(false);
		   //---
		   
		   updateNameL=new JLabel("New Song: ");
		   updateNameL.setPreferredSize(new Dimension(70,20));
		   
		   updateMTextFName=new JTextField();
		   updateMTextFName.setPreferredSize(new Dimension(110,20));
		   
		   //---
		   
		   updatePrizeL=new JLabel("Singer:");
		   updatePrizeL.setPreferredSize(new Dimension(70,20));
		   
		   updateMTextFPrize=new JTextField();
		   updateMTextFPrize.setPreferredSize(new Dimension(110,20));
		   
		   //---
		   
		   updateQualityL=new JLabel("New Genre:");
		   updateQualityL.setPreferredSize(new Dimension(70,20));
		   
		   String selectQualityUpdate[]={"Select Genre","Blues","Classical","Country","Folk","HipHop","Instrumeental","Melody","Pop","Rap","Rock"};
		   updateMComboBQuality=new JComboBox(selectQualityUpdate);
		   updateMComboBQuality.setPreferredSize(new Dimension(110,20));
		   
		   
		   updateMBtn=new JButton("Update");
		   updateMBtn.setPreferredSize(new Dimension(80,20));
		   
		   updateBackB=new JButton("Back");
		   updateBackB.setPreferredSize(new Dimension(80,20));
		   //--------------------------------------------------------------------------
		   
		   updateMTextAForResult=new JTextArea("Tracing the details result\nID\nName\nDesignation\nsex\nIDno");
		   updateMTextAForResult.setPreferredSize(new Dimension(170,150));
		   updateMTextAForResult.setEditable(false);
		   
		   updateStatusL=new JLabel("Status of update");
		   updateStatusL.setPreferredSize(new Dimension(200,20));
		   
		   //---Val
		   
		   
		   delIDV=new JLabel("Enter the ID!!! If ID is of 1 Char then ignore !");
		   delIDV.setPreferredSize(new Dimension(300,15));
		   delIDV.setForeground(Color.RED);
		   delIDV.setVisible(false);
		   
		   delNameV=new JLabel("Enter the Song!!!");
		   delNameV.setPreferredSize(new Dimension(100,10));
		   delNameV.setForeground(Color.RED);
		   delNameV.setVisible(false);
		   
		   delPrizeV=new JLabel("Enter the Singer!!!");
		   delPrizeV.setPreferredSize(new Dimension(100,10));
		   delPrizeV.setForeground(Color.RED);
		   delPrizeV.setVisible(false);
		   
		   delQualityV=new JLabel("Select Genre!!!");
		   delQualityV.setPreferredSize(new Dimension(150,20));
		   delQualityV.setForeground(Color.RED);
		   delQualityV.setVisible(false);
		   
		   //---Val
		   
		   //------------------------- Display ---------------------------------------
		   updateMenuSelectP.add(updateIDL,BorderLayout.NORTH);
		   updateMenuSelectP.add(updateMTextFID,BorderLayout.NORTH);
		   updateMenuSelectP.add(updateSelectTraceBtn,BorderLayout.NORTH);
		   updateMenuSelectP.add(updateMTextAForView,BorderLayout.NORTH);
		   //---------------------------
		   updateMenuSelectP.add(updateNameL,BorderLayout.CENTER);
		   updateMenuSelectP.add(updateMTextFName,BorderLayout.CENTER);
		   
		   updateMenuSelectP.add(updatePrizeL,BorderLayout.CENTER);
		   updateMenuSelectP.add(updateMTextFPrize,BorderLayout.CENTER);
		   
		   updateMenuSelectP.add(updateQualityL,BorderLayout.CENTER);
		   updateMenuSelectP.add(updateMComboBQuality,BorderLayout.CENTER);
		   
		   
		   //---------------------------
		   updateMenuSelectP.add(updateMBtn,BorderLayout.SOUTH);
		   updateMenuSelectP.add(updateBackB,BorderLayout.SOUTH);
		   //----------------------------------------------------------------
		   updateMenuViewP.add(updateMTextAForResult,BorderLayout.NORTH);
		   updateMenuViewP.add(updateStatusL,BorderLayout.SOUTH);
		   //---Val
		   updateMenuSelectP.add(delIDV,BorderLayout.SOUTH);
		   updateMenuSelectP.add(delNameV,BorderLayout.SOUTH);
		   updateMenuSelectP.add(delPrizeV,BorderLayout.SOUTH);
		   updateMenuSelectP.add(delQualityV,BorderLayout.SOUTH);
		   //---Val
		   
		   
		   
		   //----------------------------------------------------------------
		  }
		  
	  {
		  title=new JLabel("         PLAYLIST  MANAGEMENT SYSTEM");
		  title.setPreferredSize(new Dimension(600,100));
		  Font font = new Font("Times New Roman", Font.ITALIC,30);
		  title.setFont(font);
	  }
	  {//--setting all frames visiblity to true
		   
		  mainF.setVisible(true);
		
		  mainF.setLayout(null);
		  addF.setVisible(false);
		  addF.setLayout(null);
		  
		  viewF.setVisible(false);
		  viewF.setLayout(null);
		  
		  deleteF.setVisible(false);
		  deleteF.setLayout(null);

		  searchF.setVisible(false);
		  searchF.setLayout(null);
		  
		  updateF.setVisible(false);
		  updateF.setLayout(null);
		  
	  }
	  {
		  mainMenu.add(titlepan,BorderLayout.CENTER);
		  mainMenu.add(mainMenuSelectP);
		  mainMenu.setSize(550,300);
		   mainF.setSize(1550,800);
		   mainMenu.setVisible(true);
		   
		   addMenu.add(addMenuSelectP);
		   addMenu.add(addMenuViewP);
		   addMenu.setSize(550,300);
		   addF.setSize(1550,800);
		   addMenu.setVisible(true);
		   
		   viewMenu.add(viewMenuViewP);
		   viewMenu.setSize(550,300);
		   viewF.setSize(1550,800);
		   viewMenu.setVisible(true);
		   
		   deleteMenu.add(deleteMenuSelectP);
		   deleteMenu.add(deleteMenuViewP);
		   deleteMenu.setSize(550,300);
		   deleteF.setSize(1550,800);
		   deleteMenu.setVisible(true);
		   
		   
		   searchMenu.add(searchMenuSelectP);
		  searchMenu.add(searchMenuViewP);
		   searchMenu.setSize(550,300);
		   searchF.setSize(1550,800);
		   searchMenu.setVisible(true);
		   
		   updateMenu.add(updateMenuSelectP);
		   updateMenu.add(updateMenuViewP);
		   updateMenu.setSize(550,450);
		   updateF.setSize(1550,800);
		   updateMenu.setVisible(true);
	  }
	  {
		  titlepan.add(title,BorderLayout.CENTER);
		  
		   b1=new JButton("Add New Song Record  "); 
		   b1.setPreferredSize(new Dimension(300,30));
	        Font font5 = new Font("TIMES NEW ROMAN",Font.ITALIC, 20);
			// b1.setSize(300,300);
			  b1.setFont(font5);
			  b1.setBackground(Color.white); 
	        mainMenuSelectP.add(b1,BorderLayout.NORTH);
	        
	        b2=new JButton("View Song Record "); 
	        b2.setPreferredSize(new Dimension(300,30));
	        Font font6 = new Font("TIMES NEW ROMAN",Font.ITALIC, 20);
			// b1.setSize(300,300);
			  b2.setFont(font5);
			  b2.setBackground(Color.white); 
	       mainMenuSelectP.add(b2,BorderLayout.NORTH);
	        
	        b3=new JButton("Delete Song Record"); 
	        b3.setPreferredSize(new Dimension(300,30));
	        Font font9 = new Font("TIMES NEW ROMAN",Font.ITALIC, 20);
			// b1.setSize(300,300);
			  b3.setFont(font9);
			  b3.setBackground(Color.white); 
	       mainMenuSelectP.add(b3,BorderLayout.NORTH);
	        
	        
	        b4=new JButton("Search Song Record"); 
	        b4.setPreferredSize(new Dimension(300,30));
	       			// b1.setSize(300,300);
			  b4.setFont(font5);
			  b4.setBackground(Color.white); 
	        mainMenuSelectP.add(b4,BorderLayout.NORTH);    
	        
	        b5=new JButton("Update Song Record"); 
	        b5.setPreferredSize(new Dimension(300,30));
	       			// b1.setSize(300,300);
			  b5.setFont(font5);
			  b5.setBackground(Color.white); 
	        mainMenuSelectP.add(b5,BorderLayout.NORTH);
	        
	        
	        addMenuSelectP.add(addIDL,BorderLayout.NORTH);
	      addMenuSelectP.add(addMTextFID,BorderLayout.NORTH);
	        
	        addMenuSelectP.add(addNameL,BorderLayout.EAST);
	        addMenuSelectP.add(addMTextFName,BorderLayout.NORTH);
	        
	        addMenuSelectP.add(addPrizeL,BorderLayout.NORTH);
	        addMenuSelectP.add(addMTextFPrize,BorderLayout.NORTH);
	        
	        addMenuSelectP.add(addQualityL,BorderLayout.NORTH);
	        addMenuSelectP.add(addMComboBQuality,BorderLayout.NORTH);
	        
	        addMenuSelectP.add(addMBtn,BorderLayout.SOUTH);
	        addMenuSelectP.add(addBackB,BorderLayout.SOUTH);
	        
	        addMenuViewP.add(addMTextA,BorderLayout.NORTH);
	    //    addMenuViewP.add(addStatusL,BorderLayout.SOUTH);
	  }
	  {//ActionListener for main menu
		  b1.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent ae){
		      mainF.setVisible(false);
		      addF.setVisible(true);
		      
		    }
		  });
	  }
	  {//ActionListener for main menu
		  b2.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent ae){
		      mainF.setVisible(false);
		      addF.setVisible(false);
		      viewF.setVisible(true);
		      deleteStatusL.setText("");
		      try
		      {
		       //View details
		      
		       BufferedReader bR1 = new BufferedReader( new FileReader("Menu2.txt") ); 
		       String record;
		       
		       int i=0;
		       String DisplayView1[]=new String[1024];
		       while( ( record = bR1.readLine() ) != null )
		       {
		       StringTokenizer st = new StringTokenizer(record,",");
		       
		       IDView=st.nextToken();
		       nameView=st.nextToken();
		       PrizeView=st.nextToken();
		       SorNView=st.nextToken();
		       DisplayView1[i]="ID = "+IDView+" *** Song = "+nameView+" *** Singer = "+PrizeView+" *** Genre = "+SorNView+"\n";
		       
		       viewMTextA.append(DisplayView1[i]);
		       i++;
		       }
		       bR1.close();
		      }
		      catch(Exception ex)
		      {
		       System.out.println("Exception msg: "+ex);
		      }
		    }
		  });
	  }
	  {//ActionListener for main menu
		  b3.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent ae){
		      mainF.setVisible(false);
		      addF.setVisible(false);
		      viewF.setVisible(false);
		      deleteF.setVisible(true);
		      try
		      {
		       //View details Delete
		       
		       BufferedReader bR1DelView = new BufferedReader( new FileReader("Menu2.txt") ); 
		       String recordDelView;
		       
		       int iDel=0;
		       String DisplayDel1[]=new String[1024];
		       while( ( recordDelView = bR1DelView.readLine() ) != null )
		       {
		       StringTokenizer stDel = new StringTokenizer(recordDelView,",");
		       
		       IDDelView=stDel.nextToken();
		       nameDelView=stDel.nextToken();
		       PrizeDelView=stDel.nextToken();
		       SorNDelView=stDel.nextToken();
		       DisplayDel1[iDel]="Employee_ID = "+IDDelView+" *** Name = "+nameDelView+" *** Designation = "+PrizeDelView+" *** Sex = "+SorNDelView+"\n";
		       
		       deleteMTextA.append(DisplayDel1[iDel]);
		       iDel++;
		       }
		       bR1DelView.close();
		      }
		      catch(Exception ex)
		      {
		       System.out.println("Exception msg: "+ex);
		      }
		    }
		  });
	  }
	  {//ActionListener for main menu
		  b4.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent ae){
		    	mainF.setVisible(false);
			      addF.setVisible(false);
			      viewF.setVisible(false);
			      deleteF.setVisible(false);
			      searchF.setVisible(true);
		    }
		  });
	  }
	  
	  {//ActionListener for Back of Update menu
		    updateBackB.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent ae){
		     updateF.setVisible(false);
		      updateMTextFID.setText("");
		      updateMTextFName.setText("");
		      updateMTextFPrize.setText("");
		      updateMTextAForView.setText("");
		      updateMTextAForResult.setText("");
		      
		     mainF.setVisible(true);
		    }
		    
		   });
		  }
	  {//ActionListener for Delete btn of menu
		    deleteMBtn.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent ae){
		    try
		    {
		     if(deleteMTextFID.getText().length()!=0)
		     {
		       deleteMTextA.setText("");
		      //------------ delete ----------
		      String ID2, record1,choice3;
		      
		      
		      File tempDB = new File("MenuList1.txt");
		      File db = new File("Menu2.txt");
		      
		      
		      BufferedReader br2 = new BufferedReader( new FileReader( db ) );
		      BufferedWriter bw2 = new BufferedWriter( new FileWriter( tempDB ) );
		      
		      
		      //---------- Delete Dish Record ----------
		      
		      ID2 =deleteMTextFID.getText();
		     System.out.println(ID2);
		      
		      while( ( record1 = br2.readLine() ) != null ) {
		       System.out.println("tttt");
		       
		       if( record1.contains(ID2) ){
		    	   System.out.println("yupp");
		    	   System.out.println(record1);
		    	   continue;
		       }
		        
		     
		       bw2.write(record1);          
		       bw2.flush();                
		       bw2.newLine();                    
		   
		      }
		      
		      br2.close();
		      bw2.close();
		      
		     boolean a= db.delete();
		     
		      System.out.println(a);
		      //tempDB.renameTo(db);
		    
		      
		      boolean success = tempDB.renameTo(db);      
		      String StatusDel="Status of Deleting Song: "+success;
		      deleteStatusL.setForeground(Color.GREEN);
		      deleteStatusL.setText(StatusDel);
		      
		      
		      //-------------------------
		       //View details------------------------
		    
		       BufferedReader bR1 = new BufferedReader( new FileReader("Menu2.txt") ); 
		       String record2;
		       
		       int i=0;
		       String DisplayView1[]=new String[1024];
		       while( ( record2 = bR1.readLine() ) != null )
		       {
		        StringTokenizer st = new StringTokenizer(record2,",");
		        
		        IDDelete=st.nextToken();
		        nameDelete=st.nextToken();
		        PrizeDelete=st.nextToken();
		        SorNDelete=st.nextToken();
		        DisplayView1[i]="ID = "+IDDelete+" *** Song = "+nameDelete+" *** Singer = "+PrizeDelete+" *** Genre = "+SorNDelete+"\n";
		        
		        deleteMTextA.append(DisplayView1[i]);
		        i++;
		       }
		       bR1.close();
		       
		       deleteMTextFID.setText("");
		     }
		    }
		    catch(Exception ex)
		    {
		     System.out.println("Exception msg: "+ex);
		    }
		    }
		    
		   });
		  }
	  //Search Select Event
      searchNameL.setVisible(false);
      searchMTextFName.setVisible(false);
      searchNameBtn.setVisible(false);
      
      searchPrizeL.setVisible(false);
      searchMTextFename.setVisible(false);
      searchMTextFedes.setVisible(false);
      searchPrizeBtn.setVisible(false);
      {
		  searchb1.addActionListener(new ActionListener(){
			    public void actionPerformed(ActionEvent ae){
			    	  searchMTextFName.setText("");
			          searchMTextAForResult.setText("");
			          
			          searchNameL.setVisible(true);
			          searchMTextFName.setVisible(true);
			          searchNameBtn.setVisible(true);
			          
			          searchPrizeL.setVisible(false);
			          searchMTextFename.setVisible(false);
			          searchMTextFedes.setVisible(false);
			          searchPrizeBtn.setVisible(false);
			    }
		  });
		  searchb2.addActionListener(new ActionListener(){
			    public void actionPerformed(ActionEvent ae){
			    	 searchMTextFename.setText("");
			    	 searchMTextFedes.setText("");
			      searchMTextAForResult.setText("");
			      
			      searchNameL.setVisible(false);
			      searchMTextFName.setVisible(false);
			      searchNameBtn.setVisible(false);
			      
			      searchPrizeL.setVisible(true);
			      searchMTextFename.setVisible(true);
			      searchMTextFedes.setVisible(true);
			      searchPrizeBtn.setVisible(true);
			    }
		  });
		  
	  }
      {
    	  searchNameBtn.addActionListener(new ActionListener()
    	   {
    	   //----------------------------------------------------------------
    	    public void actionPerformed(ActionEvent ae)
    	    {
    	     try
    	     {
    	    	 int count=0;
    	    	 int count1=1;
    	    	 long filelength;
    	    	 String name;
    	    	 String designation;
    	    	 String recordSearch1;
    	   	  	 String recordSearch2;
    	         String DisplaySearch1[]=new String[1024];
    	         pos_array[0]=0;
    	         RandomAccessFile raf = new RandomAccessFile("Menu2.txt", "rw");
    	         if(searchMTextFName.getText().length()!=0)
    	         {
    	        	 nameSearchSel =searchMTextFName.getText();
    	             nameSearchSel=nameSearchSel.toLowerCase();
    	        	 while((recordSearch1 = raf.readLine()) != null)
    	        	 {
    	        		 filelength=raf.getFilePointer();
    	        		 StringTokenizer stSearchView1 = new StringTokenizer(recordSearch1,",");
    	        		 stSearchView1.nextToken();
    	        		 name=stSearchView1.nextToken();
    	        		 designation=stSearchView1.nextToken();
    	        		 primary_array[count]=name;
    	        		 secondary_array[count]=designation;
    	        		 pos_array[count1]=filelength;
    	        		 count++;
    	        		 count1++;
    	        		 
    	        	 }
    	        	 for(int y=0;y<count;y++)
    	        		 System.out.println(pos_array[y]+"|"+primary_array[y]+"|"+secondary_array[y]);
    	        	 System.out.println(count);
    	        	  int i,j;
    	        	   String tempusn;
    	        	 long tempadd;
    	        	 for(i=0;i<=count;i++)
    	        	 {
    	        	 	for(j=i+1;j<=count;j++)
    	        	 	{
    	        	 		System.out.println(primary_array[j]+"|"+primary_array[i]);
    	        	 		if(primary_array[j]== null || primary_array[i]==null)
    	        	 			break;
    	        	 		if(primary_array[j].compareTo(primary_array[i])<0)
    	        	 		{
    	        	 			System.out.println("yuppppppppppppp");
    	        	 			tempusn=primary_array[i];
    	        	 			System.out.println(tempusn);
    	        	 			primary_array[i]=primary_array[j];
    	        	 			System.out.println(primary_array[i]);
    	        	 			primary_array[j]=tempusn;
    	        	 			System.out.println(primary_array[j]);
    	        	 			tempadd=pos_array[i];
    	        	 			System.out.println(tempadd);
    	        	 			pos_array[i]=pos_array[j];
    	        	 			System.out.println(pos_array[i]);
    	        	  			pos_array[j]=tempadd;
    	        	  			System.out.println(pos_array[j]);
    	        	 		}
    	        	 		
    	        	 	}
    	        	 }
    	        	 System.out.println("Index File");
    	        	 for(int x=0;x<count;x++)
    	        	 {
    	        		 System.out.println(pos_array[x]+"\t"+primary_array[x]+"\n");
    	        	 }
    	        	 int low=0,high=count,mid,flag=0;
    	        	 int mid_final=0;
    	        	 String key;
    	        	 boolean flag1=false;
    	        	 key=nameSearchSel;
    	        	 System.out.println(key);
    	        	 for(int q=0;q<count;q++)
    	        	 {
    	        		 if(key.equals(primary_array[q]))
    	        		 {
    	        			 flag1=true;
    	        			 break;
    	        		 }
    	        	 }
    	        	 System.out.println("flag"+flag);
    	        	 if(flag1)
    	        	 {
    	           	 while(low<=high)
    	        	 {
    	        		 mid=(low+high)/2;
    	        		 System.out.println(mid);
    	        		 if(primary_array[mid].equals(key))
    	        		 {
    	   
    	        			 mid_final=mid;
    	        			 flag=1;
    	        			 break;
    	        		 }	
    	        		 else if(primary_array[mid].compareTo(key)<0)
    	        		 {
    	        			
    	        			 low=mid+1;
    	        		 }
    	        		 else
    	        		 {
    	        			
    	        			 high=mid-1;
    	        		 }				
    	        	 }
    	        	 
    	        	
    	        		 long l=pos_array[mid_final];
    	        		 System.out.println(l);
    	        		 raf.seek(l);
    	        		 System.out.println(raf.getFilePointer());
    	        		 //System.out.println(raf.readLine());
    	        		 searchMTextAForResult.append(raf.readLine());
    	        	 }
    	        	 else
    	        	 {
    	        		 searchMTextAForResult.append("primary string not found");
    	        	 }
    	         }
    	    	
    	     	raf.close();
    	    	
    	      }
    	     catch(Exception ex)
    	     {
    	      System.out.println("Exception msg: "+ex);
    	     }
    	     //----------------------------------------------------------------
    	    }
    	   });
    	   //----------------------------------------------------------------
    	   searchPrizeBtn.addActionListener(new ActionListener()
    	   {
    	    public void actionPerformed(ActionEvent ae)
    	    {
    	     try
    	     {
    	    	 nameSearchSel =searchMTextFename.getText();
    	         nameSearchSel=nameSearchSel.toLowerCase();
    	    	 System.out.println(nameSearchSel);
    	    	 
    	    	 nameSearchSe2 =searchMTextFedes.getText();
    	         nameSearchSe2=nameSearchSe2.toLowerCase();
    	    	 System.out.println(nameSearchSe2);
    	    	 String primary_array[]=new String[1000];
    	 		long pos_array[]=new long[1000];
    	 		String first_secondary_array_ename[]=new String[1000];
    	 		String first_secondary_array_eid[]=new String[1000];
    	 		String second_secondary_array_des[]=new String[1000];
    	 		String second_secondary_array_eid[]=new String[1000];
    	 		String recordSearch1;
    	 		long filelength;
    	 		int count=0,count1=1;
    	 		String eid,name,des; 
    	 		System.out.println("SECONDARY INDEXING");
    	 		RandomAccessFile ra = new RandomAccessFile("Menu2.txt", "rw");
    	 		 while((recordSearch1 = ra.readLine()) != null)
    	      	 {
    	 			 System.out.println(recordSearch1);
    	      		 filelength=ra.getFilePointer();
    	      		 StringTokenizer stSearchView1 = new StringTokenizer(recordSearch1,",");
    	      		 eid=stSearchView1.nextToken();
    	      		 name=stSearchView1.nextToken();
    	      		 des=stSearchView1.nextToken();
    	      		 primary_array[count]=eid;
    	      		 pos_array[count1]=filelength;
    	      		first_secondary_array_ename[count]=name;
    	      		first_secondary_array_eid[count]=eid;
    	      		second_secondary_array_des[count]=des;
    	      		second_secondary_array_eid[count]=eid;
    	      		 count++;
    	      		 count1++;
    	      	 }
    	 		 System.out.println("primary index");
    	      	 for(int y=0;y<count;y++)
    	      	 {
    	      		 System.out.println(pos_array[y]+"|"+primary_array[y]+"|");
    	      	}
    	      	 System.out.println("first secondary index");
    	      	for(int y=0;y<count;y++)
    	      	 {
    	      		
    	      		 System.out.println(first_secondary_array_ename[y]+"|"+primary_array[y]+"|");
    	      	}
    	      	 System.out.println("second secondary index");
    	      	for(int y=0;y<count;y++)
    	      	 {
    	      		
    	      		 System.out.println(second_secondary_array_des[y]+"|"+primary_array[y]+"|");
    	      	}
    	      	 int i,j;
    	   	   String tempusn;
    	   	 long tempadd;
    	   	 for(i=0;i<=count;i++)
    	   	 {
    	   	 	for(j=i+1;j<=count;j++)
    	   	 	{
    	   	 		if(primary_array[j]== null || primary_array[i]==null)
    	   	 			break;
    	   	 		if(primary_array[j].compareTo(primary_array[i])<0)
    	   	 		{
    	   	 			tempusn=primary_array[i];
    	   	 			primary_array[i]=primary_array[j];	
    	   	 			primary_array[j]=tempusn;
    	   	 			tempadd=pos_array[i];
    	   	 			pos_array[i]=pos_array[j];
    	   	  			pos_array[j]=tempadd;
    	   	 		}
    	   	 	}
    	   	 }
    	      	 
    	      	 System.out.println("primary index");
    	      	 for(int y=0;y<count;y++)
    	      	 {
    	      		 System.out.println(pos_array[y]+"|"+primary_array[y]+"|");
    	      	}
    	     	   String tempname;
    	     	   String tempeid;
    	     	 for(i=0;i<=count;i++)
    	     	 {
    	     	 	for(j=i+1;j<=count;j++)
    	     	 	{
    	     	 		if(first_secondary_array_ename[j]== null || first_secondary_array_ename[i]==null)
    	     	 			break;
    	     	 		if(first_secondary_array_ename[j].compareTo(first_secondary_array_ename[i])<0)
    	     	 		{
    	     	 			tempname=first_secondary_array_ename[i];
    	     	 			first_secondary_array_ename[i]=first_secondary_array_ename[j];	
    	     	 			first_secondary_array_ename[j]=tempname;
    	     	 			tempeid=first_secondary_array_eid[i];
    	     	 			first_secondary_array_eid[i]=first_secondary_array_eid[j];
    	     	 			first_secondary_array_eid[j]=tempeid;
    	     	 		}
    	     	 	}
    	     	 }
    	     	 System.out.println("secondary index");
    	     	for(int y=0;y<count;y++)
    	     	 {
    	     		 System.out.println(first_secondary_array_ename[y]+"|"+first_secondary_array_eid[y]+"|");
    	     	}
    	     	  String temepdes;
    	    	   String tempeid1;
    	    	 for(i=0;i<=count;i++)
    	    	 {
    	    	 	for(j=i+1;j<=count;j++)
    	    	 	{
    	    	 		if(second_secondary_array_des[j]== null || second_secondary_array_des[i]==null)
    	    	 			break;
    	    	 		if(second_secondary_array_des[j].compareTo(second_secondary_array_des[i])<0)
    	    	 		{
    	    	 			temepdes=second_secondary_array_des[i];
    	    	 			second_secondary_array_des[i]=second_secondary_array_des[j];	
    	    	 			second_secondary_array_des[j]=temepdes;
    	    	 			tempeid1=second_secondary_array_eid[i];
    	    	 			second_secondary_array_eid[i]=second_secondary_array_eid[j];
    	    	 			second_secondary_array_eid[j]=tempeid1;
    	    	 		}
    	    	 	}
    	    	 }
    	    	 System.out.println("second secondary index");
    	    	for(int y=0;y<count;y++)
    	    	 {
    	    		 System.out.println(second_secondary_array_des[y]+"|"+second_secondary_array_eid[y]+"|");
    	    	}
    	    	String key1=nameSearchSel;
    	    	String key2=nameSearchSe2;
    	    	boolean contains1=false;
    	    	boolean contains2=false;
    	    	for(int p=0; p < count; p++){
    				
    				//check if string array contains the string 
    				if(first_secondary_array_ename[p].equals(key1)){
    	 
    					//string found
    					contains1 = true;
    					break;
    				}
    	    	}
    	    	for(int p=0; p < count; p++){
    				
    				//check if string array contains the string 
    				if(second_secondary_array_des[p].equals(key2)){
    	 
    					//string found
    					contains2 = true;
    					break;
    				}
    	    	}
    	    	if(contains1 && contains2)
    	    	{
    	    	String sec1_result[]=new String[1000];
    	    	String sec2_result[]=new String[1000];
    	    	 int low=0,high=count,mid,flag=0;
    	    	 int mid_final=0;
    	    	// String key;
    	    	// key=nameSearchSel;
    	    	 System.out.println("Designation key:"+key2);
    	       	 while(low<=high)
    	    	 {
    	    		 mid=(low+high)/2;
    	    		 if(second_secondary_array_des[mid].equals(key2))
    	    		 {

    	    			 mid_final=mid;
    	    			 flag=1;
    	    			 break;
    	    		 }	
    	    		 else if(second_secondary_array_des[mid].compareTo(key2)<0)
    	    		 {
    	    			
    	    			 low=mid+1;
    	    		 }
    	    		 else
    	    		 {
    	    			
    	    			 high=mid-1;
    	    		 }				
    	    	 }
    	       	 int t=mid_final;
    	       	 System.out.println("mid:"+t);
    	       	 int z=0;
    	       	 int s_count=0;
    	       	sec2_result[z]=second_secondary_array_eid[t];
    	       	s_count++;
    	       	z++;
    	       	if(t!=0)
    	       	{
    	       		System.out.println("org.designation:"+key2);
    				System.out.println("prev duplicate:"+second_secondary_array_des[t-1]);

    	       	while(second_secondary_array_des[--t]==key2 && t>=0)
    	       	{
    	       		sec2_result[z]=second_secondary_array_eid[t];
    	       		z++;
    	       		s_count++;
    	       	}
    	       	}
    			t=mid_final;
    			if(t!=count-1)
    			{
    				System.out.println("org.designation:"+key2);
    				System.out.println("next duplicate:"+second_secondary_array_des[t+1]);
    			while(second_secondary_array_des[++t].equals(key2) && t<=count)
    			{
    			
    				System.out.println("yupp");
    				System.out.println(second_secondary_array_eid[t]);
    	       		sec2_result[z]=second_secondary_array_eid[t];
    	       		z++;
    	       		s_count++; 
    	       		if(t==count-1)
    	       			break;
    	       	}
    			}
    			System.out.println("second secondary search");
    			System.out.println("s_count:"+s_count);
    	    	 for(int r=0;r<s_count;r++)
    	    		 {
    	    			 System.out.println("eid:"+sec2_result[r]);
    	    		}
    	    		 int low1=0,high1=count,mid1=0,flag1=0;
    	        	 int mid_final1=0;
    	        	// String key;
    	        	// key=nameSearchSel;
    	        	 System.out.println("emoloyee name for search:"+key1);
    	           	 while(low1<=high1)
    	        	 { 
    	        		 mid1=(low1+high1)/2;
    	        		 if(first_secondary_array_ename[mid1].equals(key1))
    	        		 {

    	        			 mid_final1=mid1;
    	        			 flag1=1;
    	        			 break;
    	        		 }	
    	        		 else if(first_secondary_array_ename[mid1].compareTo(key1)<0)
    	        		 {
    	        			
    	        			 low1=mid1+1;
    	        		 }
    	        		 else
    	        		 {
    	        			
    	        			 high1=mid1-1;
    	        		 }				
    	        	 }
    	           	 int a=mid_final1;
    	           	 System.out.println("a:"+a);
    	           	  z=0;
    	           	  int r_count=0;
    	           	  if(mid_final1==0)
    	           	  {
    	           		  sec1_result[z]=first_secondary_array_eid[a];
    	           		  r_count++;
    	           		  z++;
    	           	  }
    	           	if(a!=0)
    	           	{
    	           		
    	           	 sec1_result[z]=first_secondary_array_eid[a];
    	      		  r_count++;
    	      		  z++;
    	      		System.out.println("org.ename:"+key1);
    				System.out.println("prev duplicate:"+first_secondary_array_ename[a-1]);
    	           	while(first_secondary_array_ename[--a]==key1 && a>=0)
    	           	{
    	           		
    	           		sec1_result[z]=first_secondary_array_eid[a];
    	           		z++;
    	           		r_count++;
    	           	}
    	           	}
    	           	a=mid_final1;
    	           	if(a!=count-1)
    	           	{
    	           		System.out.println("org.ename:"+key2);
    	    			System.out.println("next duplicate:"+first_secondary_array_ename[a+1]);
    	    		while(first_secondary_array_ename[++a].equals(key1) && a<=count)
    	    		{
    	           		sec1_result[z]=first_secondary_array_eid[a];
    	           		z++;
    	           		r_count++;
    	           		if(a==count-1)
    	           			break;
    	           	}
    	           	}
    	    		System.out.println("first secondary search");
    	    		for(int r=0;r<r_count;r++)
    	    		{
    	    			System.out.println("eid1:"+sec1_result[r]);
    	   		 	}
    	    		String temp="";
    	    		for(i=0;i<=r_count;i++)
    	       	 {
    	       	 	for(j=i+1;j<=r_count;j++)
    	       	 	{
    	       	 		if(sec1_result[j]== null || sec1_result[i]==null)
    	       	 			break;
    	       	 	if(sec1_result[j].compareTo(sec1_result[i])<0)
    	              	 		{
    	       	 			temp=sec1_result[i];
    	       	 			sec1_result[i]=sec1_result[j];	
    	       	 			sec1_result[j]=temp;
    	       	 		}
    	       	 	}
    	       	 }
    	    		for(int r=0;r<r_count;r++)
    	    		{
    	    			System.out.println(sec1_result[r]);
    	   		 	}

    	    		String temp1="";
    	    		for(i=0;i<=s_count;i++)
    	          	 {
    	          	 	for(j=i+1;j<=s_count;j++)
    	          	 	{
    	          	 		if(sec2_result[j]== null || sec2_result[i]==null)
    	          	 			break;
    	          	 		if(sec2_result[j].compareTo(sec2_result[i])<0)
    	                 	 {
    	          	 			temp1=sec2_result[i];
    	          	 			sec2_result[i]=sec2_result[j];	
    	          	 			sec2_result[j]=temp1;
    	          	 		}
    	          	 	}
    	          	 }
    	    		for(int r=0;r<s_count;r++)
    	    		{
    	    			System.out.println(sec2_result[r]);
    	   		 	}

    		 		
    	    		i=0;
    	    		j=0;
    	    		String s="";
    	    		System.out.println("s_count"+s_count);
    	    		System.out.println("r_count"+r_count);
    	    		while(i<r_count&&j<s_count)  {  
    	    			if(sec1_result[i].equals(sec2_result[j]))  
    	    			{
    	    				System.out.println(sec1_result[i]);  
    	    				s= sec1_result[i];
    	    				i++; 
    	    				j++; 
    	    			} 
    	    			else if(sec1_result[i].compareTo(sec2_result[j])<0)    
    	    				i++;
    	    			else
    	    				j++; 
    	    		}
    	    		System.out.println(s);
    	    	int low2=0,high2=count,mid2,flag2=0;
    	       	 int mid_final2=0;
    	       	 boolean flag3=false;
    	       	 for(int q=0;q<count;q++)
    	       	 {
    	       		 if(s.equals(primary_array[q]))
    	       		 {
    	       			 flag3=true;
    	       			 break;
    	       		 }
    	       	 }
    	       	 System.out.println("flag"+flag3);
    	       	 if(flag3)
    	       	 {
    	          	 while(low2<=high2)
    	       	 {
    	       		 mid2=(low2+high2)/2;
    	       		 System.out.println(mid2);
    	       		 if(primary_array[mid2].equals(s))
    	       		 {
    	  
    	       			 mid_final2=mid2;
    	       			 flag2=1;
    	       			 break;
    	       		 }	
    	       		 else if(primary_array[mid2].compareTo(s)<0)
    	       		 {
    	       			
    	       			 low2=mid2+1;
    	       		 }
    	       		 else
    	       		 {
    	       			
    	       			 high2=mid2-1;
    	       		 }				
    	       	 }
    	       	 
    	       	
    	       		 long l2=pos_array[mid_final2];
    	       		 System.out.println("pos"+l2);
    	       		 ra.seek(l2);
    	       		 System.out.println("pointer"+ra.getFilePointer());
    	       		 //System.out.println(raf.readLine());
    	       		 searchMTextAForResult.append(ra.readLine());
    	       	 }
    	       	 else
    	       	 {
    	       		 searchMTextAForResult.append("primary string not found");
    	       	 }
    	    		
    	       	ra.close();
    	    	}
    	    	else{
    	    		boolean c1=contains1;
    	    		boolean c2=contains2;
    	    		if(!c1 && !c2)
    	    			 searchMTextAForResult.append("Song name and Singer name not present in file");
    	    		else if(!c1)
    	    			 searchMTextAForResult.append("Song name not present in file");
    	    		else
    	    			 searchMTextAForResult.append("Singer name not present in file");
    	    	}
    	     }
    	     catch(Exception ex)
    	     {
    	      System.out.println("Exception msg: "+ex);
    	     }
    	     //----------------------------------------------------------------
    	    }
    	   });
    	   //----------------------------------------------------------------
      }

      {//ActionListener for main menu
		  b5.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent ae){
		      mainF.setVisible(false);
		      addF.setVisible(false);
		      viewF.setVisible(false);
		      deleteF.setVisible(false);
		      searchF.setVisible(false);
		      updateF.setVisible(true);
		      
		    }
		  });
	  }
      {//ActionListener for main menu
		 
		    //-------------------------------- Update start --------------------------------
		      {
		       updateMTextAForView.setText("");
		       updateMTextAForResult.setText("");
		       updateStatusL.setText("");
		            updateSelectTraceBtn.addActionListener(new ActionListener(){
		         public void actionPerformed(ActionEvent ae)
		         {
		          try
		          {
		         	 IDUpdate1 =updateMTextFID.getText();
		              File dbUpdate = new File("Menu2.txt");
		              File tempDBUpdate = new File("MenuList_temp.txt");
		              BufferedReader brUpdate = new BufferedReader( new FileReader(dbUpdate) );
		              BufferedWriter bwUpdate = new BufferedWriter( new FileWriter(tempDBUpdate) );
		             
		             
		             updateMTextAForView.setText("");
		             while( ( recordUpdate1 = brUpdate.readLine() ) != null )
		             {
		              String DisplayUpdate1;
		              
		              StringTokenizer stUpdate1 = new StringTokenizer(recordUpdate1,",");
		              String id=stUpdate1.nextToken();
		              String name=stUpdate1.nextToken();
		              String des=stUpdate1.nextToken();
		              String s=stUpdate1.nextToken();
		              if( id.equals(IDUpdate1) ) {
		               
		               DisplayUpdate1="-- Current Record --\nID = "+id+"\n Song = "+name+"\n Singer = "+des+"\n Genre = "+s+"\n";
		              
		                updateMTextAForView.setText(DisplayUpdate1);
		                
		               
		              }
		             }       
		             brUpdate.close();
		             bwUpdate.close();
		             }
		             catch(Exception ex)
		             {
		              System.out.println("Exception msg: "+ex);
		             }
		            }
		           });
		               
		         } 
		         /****/  
		         { 
		           //value input
		              
		           
		           //-----------------------------
		           
		           
		            updateMBtn.addActionListener(new ActionListener(){
		            public void actionPerformed(ActionEvent ae)
		            {
		             
		             try
		             {
		              
		              if(updateMTextFPrize.getText().length()!=0&&updateMTextFName.getText().length()!=0)
		              {
		              IDUpdate1 =updateMTextFID.getText();
		             
		              BufferedReader brUpdate = new BufferedReader( new FileReader("Menu2.txt") );
		              BufferedWriter bwUpdate2 = new BufferedWriter( new FileWriter("MenuList_temp.txt") );
		              //updateMTextFID.setText("");
		              updateMTextAForResult.setText("");
		              
		              IDUpdate2nd = IDUpdate1;
		              System.out.println(IDUpdate2nd);
		              newNameUpdate = updateMTextFName.getText();
		              newNameUpdate=newNameUpdate.toLowerCase();
		              
		              newPrizeUpdate =  updateMTextFPrize.getText();
		              newQualityUpdate= updateMComboBQuality.getSelectedItem().toString();
		                
		              splittUpdate=IDUpdate2nd;
		               
		          //   String IDnoUpdate=splittUpdate.substring(1, splittUpdate.length() -1);
		              
		              BufferedReader brUpdate2 = new BufferedReader( new FileReader("Menu2.txt") );
		              
		              while( (recordUpdate2 = brUpdate2.readLine()) != null )
		              {       
		               if(recordUpdate2.contains(IDUpdate2nd))
		               {
		                bwUpdate2.write(IDUpdate2nd+","+newNameUpdate+","+newPrizeUpdate+","+newQualityUpdate+"$");
		                
		               }
		               else
		               {
		                bwUpdate2.write(recordUpdate2); 
		               }  
		                    
		               bwUpdate2.flush();
		               bwUpdate2.newLine();
		              }
		              brUpdate.close();
		              bwUpdate2.close();
		              brUpdate2.close();  
		              
		              File dbUpdate2 = new File("Menu2.txt");
		               File tempDBUpdate2 = new File("MenuList_temp.txt");
		               
		               dbUpdate2.delete();
		               
		               boolean success =tempDBUpdate2.renameTo(dbUpdate2);
		               
		               
		             /*  String SuccessUpdate="Record Updation status: "+success;
		               
		           if(success==true)
		           {
		            updateStatusL.setForeground(Color.GREEN);
		            updateStatusL.setText(SuccessUpdate);
		           }
		           else
		           {
		            updateStatusL.setForeground(Color.RED);
		            updateStatusL.setText(SuccessUpdate);
		           }*/
		           String ViewUpdate="-- Updated Record --\nID = "+IDUpdate2nd+"\n Song = "+newNameUpdate+"\n Singer = "+newPrizeUpdate+"\n Genre= "+newQualityUpdate;
		           updateMTextAForResult.setText(ViewUpdate);
		           updateMTextFID.setText("");
		           updateMTextFName.setText("");
		           updateMTextFPrize.setText("");
		           }
		          }
		          catch(Exception ex)
		          {
		           System.out.println("Exception msg: "+ex);
		          }
		         }
		        });
		             
		     //-----------------   
		      }
		      //-------------------------------- Update end --------------------------------
		    
	  }
	//ActionListener for Back of add menu
	  {
	    addBackB.addActionListener(new ActionListener(){
	    public void actionPerformed(ActionEvent ae){
	     addF.setVisible(false);
	     mainF.setVisible(true);
	     addMTextFID.setText("");
	     addMTextFName.setText("");
	     addMTextFPrize.setText("");
	     addMTextA.setText("");
	     //addStatusL.setText("");
	    }
	    
	   });
	    {//ActionListener for Back of view menu
	        viewBackB.addActionListener(new ActionListener(){
	        public void actionPerformed(ActionEvent ae){
	         viewF.setVisible(false);
	         mainF.setVisible(true);
	         viewMTextA.setText("");
	        }
	        
	       });
	      }
	  } 
	  {//ActionListener for Back of Delete menu
		    deleteBackB.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent ae){
		     deleteF.setVisible(false);
		     mainF.setVisible(true);
		     deleteMTextFID.setText("");
		     deleteStatusL.setText("");
		     deleteMTextA.setText("");
		    }
		    
		   });
		  }
	  
	  {//ActionListener for Back of Search menu
	    searchBackB.addActionListener(new ActionListener(){
	    public void actionPerformed(ActionEvent ae){
	     searchF.setVisible(false);
	     mainF.setVisible(true);
	     searchMTextFName.setText("");
	     searchMTextFename.setText("");
	     searchMTextFedes.setText("");
	     searchMTextAForResult.setText("");
	    }
	   });
	  }
	  
	  {//update Validation-----------------------
		  
		    updateMTextFID.addKeyListener(new KeyAdapter()
		    {
		     public void keyTyped(KeyEvent ke)
		     {
		      delValidationID=updateMTextFID.getText();
		      
		      if(delValidationID.equals(""))
		      {
		       delIDV.setVisible(true);
		      }
		      else if(delValidationID.length()>0)
		      {
		       delIDV.setVisible(false);
		      }
		     }
		    });
		    
		    updateMTextFName.addKeyListener(new KeyAdapter()
		    {
		     public void keyTyped(KeyEvent ke)
		     {
		      delValidationName=updateMTextFName.getText();
		      if(delValidationName.length()==0)
		      {
		       delNameV.setVisible(true);
		      }
		      else if(delValidationName.length()>0)
		      {
		       delNameV.setVisible(false);
		      }
		     }
		    });
		    
		    updateMTextFPrize.addKeyListener(new KeyAdapter()
		    {
		     public void keyTyped(KeyEvent ke)
		     {
		      delValidationPrize=updateMTextFPrize.getText();
		      if(delValidationPrize.length()==0)
		      {
		       delPrizeV.setVisible(true);
		      }
		      else if(delValidationPrize.length()>0)
		      {
		       delPrizeV.setVisible(false);
		      }
		     }
		    });
		    
		    updateMComboBQuality.addItemListener(new ItemListener()
		    {
		     public void itemStateChanged(ItemEvent e)
		     {      
		      delValidationQuality=updateMComboBQuality.getSelectedItem().toString();
		      String addQV1="Select Quality";
		      String addQV2="Special";
		      String addQV3="Normal";
		      if(delValidationQuality.equals(addQV1))
		      {
		       delQualityV.setVisible(true);
		      }
		      else if((delValidationQuality.equals(addQV2))||(delValidationQuality.equals(addQV2)))
		      {
		       delQualityV.setVisible(false);
		      }
		     }          
		    });

		    
		 }
	  {//Adding details
		   addMBtn.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent ae)
		    {
		     
		     try
		     {
		      String addQval="Select Quality";
		      if(addMTextFID.getText().length()!=0&&addMTextFName.getText().length()!=0&&addMTextFPrize.getText().length()!=0&&(!(addMComboBQuality.getSelectedItem().toString().equals(addQval))))
		      {
		       BufferedWriter bW1=new BufferedWriter(new FileWriter("Menu2.txt",true));
		       ID = " "+addMTextFID.getText()+" ";
		       name = addMTextFName.getText();
		       Prize = addMTextFPrize.getText();
		       Quality = addMComboBQuality.getSelectedItem().toString();
		       name=name.toLowerCase();
		       
		       String splitt=ID;
		       
		       String IDno=splitt.substring(1, splitt.length() -1);
		       bW1.write(IDno+","+name+","+Prize+","+Quality+"$");
		       bW1.flush();
		       bW1.newLine();
		       bW1.close();
		       String DetailsAdd="ID1: "+ID+"\n Song: "+name+"\n Singer: "+Prize+"\n Genre: "+Quality;
		      addMTextA.setText(DetailsAdd);
		       //Code Created By Youtube Channel LEGEND MORTAL Channel Link: http://goo.gl/1Q6uYh
		       addStatusL.setForeground(Color.GREEN);
		       addStatusL.setText("Added Details Successfully");
		       addMTextFID.setText("");
		       addMTextFName.setText("");
		       addMTextFPrize.setText("");
		      }
		   
		     }
		     
		     catch(Exception ex)
		     {
		      System.out.println("Exception msg: "+ex);
		     }
		    }
		   });
		  }
	   //-}-Main Menu Container
}

public static void main(String args[])
{//Code Created By Youtube Channel LEGEND MORTAL Channel Link: http://goo.gl/1Q6uYh
  new SongDataSwing();
}
}
