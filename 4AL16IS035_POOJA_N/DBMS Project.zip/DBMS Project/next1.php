<html>
<head>
<title>next</title>
<link rel="stylesheet" type="text/css" href="css/bs.css">
<script type="text/javascript" src="js/bs.js"></script>
<style type="text/css">
		body{
	background-image: url(img/nextt.jpg);
	background-repeat: no-repeat;
	background-size: 100%;
}#btn_b1 {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;

	</style>
</head>
<body>
<br><br>


<br><br><br><br>
<center><a href="addbilling.php"><button class="btn btn-danger"><font style="Serif">ADD billing DETAILS</button></a><br><br><<br>
	<center><a href="addcus.php"><button class="btn btn-secondary"><font style="Serif">ADD customer DETAILS</button></a><br><br><<br>
<center><a href="addemp.php"><button class="btn btn-success"><font style="Serif">ADD employee DETAILS</button></a><br><br><<br>
<center><a href="additem.php"><button id="btn_b1"><font style="Serif">ADD item DETAILS</button></a><br><br><br>
	<center><a href="addrate.php"><button id="btn_b1"><font style="Serif">ADD rate DETAILS</button></a>
		




</body>
</html>