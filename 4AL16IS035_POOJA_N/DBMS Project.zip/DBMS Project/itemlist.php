<html>
<head>
<title> All item Deatils </title>
<link rel="stylesheet" type="text/css" href="style1.css">
<h1><center><font color="#0707F" size="5" style="Times New Roman">All item Details</font></center><br></h1>
<style type="text/css">
    #btn_b1 {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
}
body{
    background-image: url(img/add.jpg);
    background-repeat: no-repeat;
    background-size: 100%;
}
th{
    color:'white';
    text-decoration-color: 'white';
}
</style>
</head>
<body >
	<center><font color='white'><table width="500" cellpadding=5celspacing=5 border=1><tr><th><font color='white'> Item ID</font></th><th><font color='white'> item weight</font></th><th> 
<font color='white'>item Type </font></th><th> <font color='white'>item category</font></th></tr>
<form>
<div id="main-wrapper">
<?php


$servername = "localhost";
$username = "root";
$password="";
$dbname = "jewelery";

// Create connection
$conn = mysqli_connect($servername,$username,$password,$dbname);
// Check connection
if ($conn->connect_error) {
echo "<script>alert('Invalid credentials');</script>";
} 

$sql = "SELECT * FROM additem;";
$result = $conn->query($sql);

if ($result->num_rows > 0) 

  
     
    while($row = $result->fetch_assoc()):?>
     <tr>
     	<td><font color='white'><?php echo $row["iid"];?></font></td>
     	<td><font color='white'><?php echo $row["iweight"];?></font></td>
     	<td><font color='white'><?php echo $row["itype"];?></font></td>
	   <td><font color='white'><?php echo $row["icategory"];?></font></td>


     	
     </tr>
	
    <?php endwhile;?>
    </table>

</center>

<center><br><br>
<a href="home.php"><input type="button" id="submit_btn" value="Logout"></a>
		</form></center>
</div>	<br><br><br> 

</body>
</html>
