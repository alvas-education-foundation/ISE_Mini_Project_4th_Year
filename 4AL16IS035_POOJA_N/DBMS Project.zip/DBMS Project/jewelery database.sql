-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 23, 2018 at 07:31 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jewelery`
--

-- --------------------------------------------------------

--
-- Table structure for table `addbilling`
--

CREATE TABLE `addbilling` (
  `bid` varchar(20) NOT NULL,
  `bdate` date NOT NULL,
  `bitemid` varchar(20) NOT NULL,
  `beid` varchar(20) NOT NULL,
  `bcid` varchar(20) NOT NULL,
  `bamt` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `addcus`
--

CREATE TABLE `addcus` (
  `cid` varchar(20) NOT NULL,
  `cname` varchar(20) NOT NULL,
  `caddress` varchar(20) NOT NULL,
  `cphno` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `addemp`
--

CREATE TABLE `addemp` (
  `eid` varchar(20) NOT NULL,
  `ename` varchar(20) NOT NULL,
  `ephno` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `additem`
--

CREATE TABLE `additem` (
  `iid` varchar(20) NOT NULL,
  `iweight` int(5) NOT NULL,
  `itype` varchar(20) NOT NULL,
  `icategory` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `addrate`
--

CREATE TABLE `addrate` (
  `rgold` int(5) NOT NULL,
  `rsilver` int(5) NOT NULL,
  `rplatinum` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addbilling`
--
ALTER TABLE `addbilling`
  ADD PRIMARY KEY (`bid`),
  ADD KEY `bitemid` (`bitemid`),
  ADD KEY `beid` (`beid`),
  ADD KEY `bcid` (`bcid`);

--
-- Indexes for table `addcus`
--
ALTER TABLE `addcus`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `addemp`
--
ALTER TABLE `addemp`
  ADD PRIMARY KEY (`eid`);

--
-- Indexes for table `additem`
--
ALTER TABLE `additem`
  ADD PRIMARY KEY (`iid`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `addbilling`
--
ALTER TABLE `addbilling`
  ADD CONSTRAINT `addbilling_ibfk_1` FOREIGN KEY (`bitemid`) REFERENCES `additem` (`iid`),
  ADD CONSTRAINT `addbilling_ibfk_2` FOREIGN KEY (`beid`) REFERENCES `addemp` (`eid`),
  ADD CONSTRAINT `addbilling_ibfk_3` FOREIGN KEY (`bcid`) REFERENCES `addcus` (`cid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
