<html>
<head>
<title> All billing Deatils </title>
<link rel="stylesheet" type="text/css" href="style1.css">
<h1><center><font color="#0707F" size="5" style="Times New Roman">All billing List</font></center></h1>
<style type="text/css">
    #btn_b1 {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
}
body{
    background-image: url(img/add.jpg);
    background-repeat: no-repeat;
    background-size: 100%;
}
th{
    color:'white';
    text-decoration-color: 'white';
}
}
</style>
</head>
<body >
	<center><font color='white'><table width="500" cellpadding=5celspacing=5 border=1><tr><th><font color='white'> billing ID</font></th><th><font color='white'> billing date</font></th><th><font color='white'>billing item ID</font> </th><th><font color='white'> billing employee ID</font></th></tr>
 billing customer ID</th></tr><font color='white'> billing amount</th></tr></font>
<form>
<div id="main-wrapper">

<?php


$servername = "localhost";
$username = "root";
$password="";
$dbname = "jewelery";

// Create connection
$conn = mysqli_connect($servername,$username,$password,$dbname);
// Check connection
if ($conn->connect_error) {
echo "<script>alert('Invalid credentials');</script>";
} 

$sql = "SELECT * FROM addbilling;";
$result = $conn->query($sql);
if ($result->num_rows > 0) 
     
    while($row = $result->fetch_assoc()):?>
     <tr>
     	<td><font color='white'><?php echo $row["bid"];?></font></td>
     	<td><font color='white'><?php echo $row["bdate"];?></font></td>
            <td><font color='white'><?php echo $row["bitemid"];?></font></td>
     	<td><font color='white'><?php echo $row["beid"];?></font></td>
	<td><font color='white'><?php echo $row["bcid"];?></font></td>
	<td><font color='white'><?php echo $row["bamt"];?></font></td>

 </tr>
	
    <?php endwhile;?>
    </table>

</center>

<center><br>
<a href="home.php"> <input type="button" id="submit_btn" value="Logout"></a>
		</form></center>
</div>	<br><br><br> 

</body>
</html>
