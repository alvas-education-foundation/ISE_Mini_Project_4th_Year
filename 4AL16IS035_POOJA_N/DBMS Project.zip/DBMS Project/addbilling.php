<html>
<head>
<title>Add Billing Details</title>
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
	#btn_b1 {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
}
body{
	background-image: url(img/add.jpg);
	background-repeat: no-repeat;
	background-size: 100%;
}
</style>
</head>
<body ><br><b><center><font color="#0707F" size="5" style="Times New Roman"> 
		Add Billing Details</font></center></b> <br>
	
<form action="addbilling.php" method="post">
<div id="main-wrapper"><b>
		
billing ID : <input class="inputvalues" type="text" name="bid" required/><br><br>
billing date: <input class="inputvalues" type="text" name="bdate" required/><br><br>
billing item ID: <input class="inputvalues" type="text" name="bitemid" required/><br><br>
billing employee ID: <input class="inputvalues" type="text"  name="beid" required/><br><br>
billing customer ID: <input class="inputvalues" type="text"  name="bcid" required/><br><br>
billing amount: <input class="inputvalues" type="text"  name="bamt" required/><br><br>


<center><input type="submit" id="submit_btn" name="submit_btn" value="Save"></b></center>
<?php
$servername = "localhost";
$username = "root";
$password="";
$dbname = "jewelery";


// Create connection
$conn = mysqli_connect($servername,$username,$password,$dbname);
// Check connection
if ($conn->connect_error)
{
echo "<script>alert('Invalid credentials');</script>";
} 
else if(isset($_POST['submit_btn']))
{
	  $bid=$_POST['bid'];
      $bdate=$_POST['bdate'];
     
      $bitemid=$_POST['bitemid'];
       $beid=$_POST['beid'];
	$bcid=$_POST['bcid'];
	$bamt=$_POST['bamt'];

      $sql = "insert into addbilling values('$bid','$bdate','$bitemid','$beid','$bcid','$bamt')";
      $result = $conn->query($sql);
     
      
  }


?>	
<center>

</div>	<br><br><br> 

</body>
</html>
