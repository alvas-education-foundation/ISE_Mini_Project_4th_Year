<html>
<head>
<title> Procedure</title>
<link rel="stylesheet" type="text/css" href="style1.css">
<h1><center><font color="#0707F" size="5" style="Times New Roman">billing Details Using PROCEDURE </font></center></h1>
</head>
<body background="DBMSImages/sky.png">
    <center> <table width="500" cellpadding=5celspacing=5 border=1><tr><th> billing ID </th><th> billing date</th><th>billing item ID</th><th> billing employee ID</th><th>billing customer ID</th><th>  billing amount</th></tr>
<form>
<div id="main-wrapper">
<?php


$servername = "localhost";
$username = "root";
$password="";
$dbname = "jewelery";

// Create connection
$conn = mysqli_connect($servername,$username,$password,$dbname);
// Check connection
if ($conn->connect_error) {
echo "<script>alert('Invalid credentials');</script>";
} 

$sql = "call Get_All_Products();";
$result = $conn->query($sql);

if ($result->num_rows > 0) 
     
    while($row = $result->fetch_assoc()):?>
     <tr>
  <td><?php echo $row["bid"];?></td>
        <td><?php echo $row["bdate"];?></td>
            <td><?php echo $row["bitemid"];?></td>
        <td><?php echo $row["beid"];?></td>
	<td><?php echo $row["bcid"];?></td>
	<td><?php echo $row["bamt"];?></td>

     	
     </tr>
	
    <?php endwhile;?>
    </table>

</center>

<center><br>
<a href="home.php"> <input type="button" id="submit_btn" value="Logout"></a>
		</form></center>
</div>	<br><br><br> 

</body>
</html>
