<html>
<head>
<title>next1</title>
<style type="text/css">
		body{
	background-image: url(img/nextt.jpg);
	background-repeat: no-repeat;
	background-size: 100%;
}#btn_b1 {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;

	</style>
</head>
<body>
<br><br>
<link rel="stylesheet" type="text/css" href="style.css">

<br><br><br><br>
<center><a href="next1.php"><button class="button button1"><font style="Serif">GOTO ADD DETAILS</button></a><br><br><<br>
	<center><a href="next2.php"><button class="button button1"><font style="Serif">GOTO VIEW LIST</button></a><br><br><<br>




</body>
</html>