<html>
<head>
<title>next1</title>
<style type="text/css">
	.button{
		background-color: green;
		color: white;
	}
</style>
</head>
<body background="img/nextt.jpg">
<br><br>
<link rel="stylesheet" type="text/css" href="style.css">

<br><br><br><br>
<center><a href="billinglist.php"><button class="button button5"><font style="Serif">VIEW billing LIST</button></a><br><br><<br>
	<center><a href="cuslist.php"><button class="button button5"><font style="Serif">VIEW customer LIST</button></a><br><br><<br>
<center><a href="emplist.php"><button class="button button5"><font style="Serif">VIEW employee LIST</button></a><br><br><<br>
<center><a href="itemlist.php"><button class="button button5"><font style="Serif">VIEW item LIST</button></a>
	<center><a href="ratelist.php"><button class="button button5"><font style="Serif">VIEW rate LIST</button></a>
		




</body>
</html>