<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>FoodCart</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
    body{
        background: url('images/i/a4.jpg');
        background-repeat: repeat;
        background-size: 100%;
        z-index: -1;}
    input{
        border:none;
        outline:none;
        font-family:Arial;
        font-size: 25px;
        color: rgb(243, 95, 9);
        font-weight: bolder;
        height: 60px;   
        width:150px;
        margin-top: 40px;
        background-color: rgb(248, 196, 24);
    }
    font{
        font-family:Showcard Gothic;
        color:rgb(248, 196, 24);
        font-size:45pt;
    }
    input:hover{background-color: rgba(6, 121, 2, 0.938); color: rgb(248, 196, 24);}
    </style>
</head>
<body><br><br><br><br><br><br><br><br><br><br>
    <center>
        <font>Welcome to FoodCart</font><br>
        <a href="home.php"><input type='button' value="Let's Go"></a>
    </center>
</body>
</html>
<?php
    //header('location:home.php');
?>