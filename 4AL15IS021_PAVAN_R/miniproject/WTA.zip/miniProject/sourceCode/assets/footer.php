<footer>
    <div id="sec"><a href="adminlogin.php">Admin Login</a><hr color="#d1a30c">
    </div>
    <div id="sec"><a href="aboutus.php">About Us</a><hr color="#d1a30c">
    </div>
    <div id="sec"><a href="feedback.php">Feedback</a><hr color="#d1a30c">
    </div>
</footer>
<style>
    a{ color: #d1a30c;}
    footer{
        position: absolute;
        bottom:0px;
        left: 0px;
        width:100%;
        color:rgb(209, 163, 12);
        border-radius: 3px;
        background-color: rgba(83, 33, 73, 0.938);}
    #sec{
        float: left;
        width:32%;
        padding-top: 10px;
        padding-left: 8px;
        padding-right: 8px;
    }
</style>