<html>
<head>
<title>next1</title>
</head>
<body background="DBMSImages/next.jpg">
<br><br>
<link rel="stylesheet" type="text/css" href="style.css">

<br><br><br><br>
<center><a href="comlist.php"><button class="button button5"><font style="Serif">VIEW COMPANY LIST</button></a><br><br><<br>
	<center><a href="suplist.php"><button class="button button5"><font style="Serif">VIEW SUPPLIERS LIST</button></a><br><br><<br>
<center><a href="medlist.php"><button class="button button5"><font style="Serif">VIEW MEDICINES LIST</button></a><br><br><<br>
<center><a href="stolist.php"><button class="button button5"><font style="Serif">VIEW STOCK LIST</button></a>
	<center><a href="cuslist.php"><button class="button button5"><font style="Serif">VIEW CUSTOMERS LIST</button></a>
		




</body>
</html>