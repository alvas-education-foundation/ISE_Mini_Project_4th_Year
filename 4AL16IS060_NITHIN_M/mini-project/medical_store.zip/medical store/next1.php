<html>
<head>
<title>next</title>
</head>
<body background="DBMSImages/next.jpg">
<br><br>
<link rel="stylesheet" type="text/css" href="style.css">

<br><br><br><br>
<center><a href="addcompany.php"><button class="button button5"><font style="Serif">ADD COMPANY DETAILS</button></a><br><br><<br>
	<center><a href="addsup.php"><button class="button button5"><font style="Serif">ADD SUPPLIER DETAILS</button></a><br><br><<br>
<center><a href="addmed.php"><button class="button button5"><font style="Serif">ADD MEDICINE DETAILS</button></a><br><br><<br>
<center><a href="addstock.php"><button class="button button5"><font style="Serif">ADD STOCK DETAILS</button></a>
	<center><a href="addcus.php"><button class="button button5"><font style="Serif">ADD CUSTOMER DETAILS</button></a>
		




</body>
</html>