<html>
<head>
<title>Welcome page</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body background="DBMSImages/hom2.jpg"><br><br><br><br>
<b><center><font color= "#191970" size="8" style="Arial">WELCOME TO MEDICAL STOCK DATABASE SYSTEM</font></center></b><br><br><br><br>
<center><a href="login.php"><button class="button button5"><font style="Serif">Goto Login</button></a></center>
</body>
</html>