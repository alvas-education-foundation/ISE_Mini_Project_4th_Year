<html>
<head>
<title>Individual Medicine Details</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body background="DBMSImages/sky.png">
	

<form method="post" action="serch.php"><br><br><br><br><br><br><br><br>
	<div id="main-wrapper">
<center><b> Medical Batch No: <input type=" text" id="inputvalues" name="name" placeholder="manufactureid" required></b>

<input type="submit" name="search" id="submit_btn2" size="18"></center>

<?php

$servername = "localhost";
$username = "ganesh";
$password="1234";
$dbname = "medical_store";
if(isset($_POST['search']))
{
	$xname =$_POST['name'];

	// Create connection
	$conn = mysqli_connect($servername,$username,$password,$dbname);
	// Check connection
	if ($conn->connect_error) {
	echo "<script>alert('Invalid credentials');</script>";
	} 

$sql = "SELECT * FROM addmed where medmanufactureid='$xname';";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

   ?>
   </div>
   <center> <table width="500" cellpadding=5celspacing=5 border=1><tr><th> Medicine Batch No </th><th> Medicine Name </th><th> Medicine Manufacture ID </th><th> Medcine Company </th><th> Medicine Quantity </th><th> Medicine Exp Date </th><th> Medicine Purchase Date </th><th> Medicine Type </th><th> Medicine Purchase Price </th><th> Supplier ID</th></tr>
   	<?php
    while($row = $result->fetch_assoc()) {

     echo "<tr><td>".$row["medbatchno"]."</td><td>".$row["medname"]."</td><td>".$row["medmanufactureid"]."</td><td>".$row["medcompany"]."</td><td>".$row["medquantity"]."</td><td>".$row["medexpdate"]."</td><td>".$row["medpurchasedate"]."</td><td>".$row["medtype"]."</td><td>".$row["medpurchaseprice"]."</td><td>".$row["supid"]."</td>";
	
    }
   echo "</table>";
}

 else {
    echo "0 results";
}
}
?>	<br><br>
<center>
<a href="home.php"> <input type="button" id="submit_btn2" value="Logout"></a>
		</form></center>
	<br><br><br> 

</body>
</html>
