<html>
<head>
<title>next1</title>
</head>
<body background="DBMSImages/next.jpg">
<br><br>
<link rel="stylesheet" type="text/css" href="style.css">

<br><br><br><br>
<center><a href="next1.php"><button class="button button5"><font style="Serif">GOTO ADD DETAILS</button></a><br><br><<br>
	<center><a href="next2.php"><button class="button button5"><font style="Serif">GOTO VIEW LIST</button></a><br><br><<br>




</body>
</html>