<?php
	include('db_connection.php');
   // header('Content-Type: application/json');
    $aResult = array();
	switch($_POST['functionname']) {
		case 'add_1':
			$name = $_POST['name'];
			$table = $_POST['table'];
			echo $success = mysqli_query($conn,"INSERT INTO ".$table." (`name`) VALUES ('$name')");
			mysqli_close($conn);
		break;
		case 'addpest':
			$name = $_POST['name'];
			$disease = $_POST['disease'];
			echo $success = mysqli_query($conn,"INSERT INTO pesticide (`pest_name`, `disease_name`) VALUES ('$name', '$disease')");
			mysqli_close($conn);
		break;
		case 'addplough':
			$name = $_POST['name'];
			$tool = $_POST['tool'];
			echo $success = mysqli_query($conn,"INSERT INTO plough (`plough_name`, `tool_name`) VALUES ('$name', '$tool')");
			mysqli_close($conn);
		break;
		case 'delete':
			$id = $_POST['id'];
			$table = $_POST['table'];
			$column = $_POST['column'];
			echo $success = mysqli_query($conn,"Delete from ".$table."  WHERE ".$column."=".$id."");
			mysqli_close($conn);
		break;
		default:
		   $aResult['error'] = 'Not found function '.$_POST['functionname'].'!';
		break;
	}
?>