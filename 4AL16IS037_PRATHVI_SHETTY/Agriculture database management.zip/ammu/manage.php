<?php 
  session_start(); 
  include('server.php');
  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<!DOCTYPE html>
<html>
<head>
  <title>Registration system PHP and MySQL</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
	<nav class="navbar navbar-inverse">
		<div class="container-fluid">
			<div class="navbar-header">
				<a class="navbar-brand" href="#">Agriculture</a>
			</div>
			<ul class="nav navbar-nav">
				<li><a href="index.php">Home</a></li>
				<li class="active"><a href="manage.php">Management</a></li>
			</ul>
		</div>
	</nav>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h5> Table CROP</h5>
				<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addcrop">Add crop</button>
				<div class="table-responsive">
					<table class="table table-bordered">
						<thead>
							<tr>
								<!--<th>#</th>-->
								<th>#</th>
								<th>Name</th>
								<th>Action</th>
							</tr>
						</thead>
						</tbody>
						<?php
							$query = "SELECT * from crop";
							$result = mysqli_query($db, $query);
							$count = $result->num_rows;
							if ($count > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()){
								?>
								<tr>
									<td><?php echo $row["crop_id"]?></td>
									<td><?php echo $row["name"]?></td>
									<td><button type="button" class="btn btn-danger deletebtn" data-column="crop_id" data-table="crop" data-id="<?php echo $row["crop_id"]?>">Add crop</button></td>
								</tr>
								<?php
								}
							} else {
								echo "<tr><td colspan='3'> No result found</td></tr>";
							}
							//$conn->close();
						?>								
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<h5> Table FERTILIZER</h5>
				<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addfert">Add fertilizer</button>
				<div class="table-responsive">
					<table class="table table-bordered">
						<thead>
							<tr>
								<!--<th>#</th>-->
								<th>#</th>
								<th>Name</th>
								<th>Action</th>
							</tr>
						</thead>
						</tbody>
						<?php
							$query = "SELECT * from fertilizer";
							$result = mysqli_query($db, $query);
							$count = $result->num_rows;
							if ($count > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()){
								?>
								<tr>
									<td><?php echo $row["fert_id"]?></td>
									<td><?php echo $row["name"]?></td>
									<td><button type="button" class="btn btn-danger deletebtn" data-column="fert_id" data-table="fertilizer" data-id="<?php echo $row["fert_id"]?>">Add crop</button></td>
								</tr>
								<?php
								}
							} else {
								echo "<tr><td colspan='3'> No result found</td></tr>";
							}
							//$conn->close();
						?>								
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<h5> Table PESTICIDE</h5>
				<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addpest">Add pestiside</button>
				<div class="table-responsive">
					<table class="table table-bordered">
						<thead>
							<tr>
								<!--<th>#</th>-->
								<th>#</th>
								<th>Name</th>
								<th>Disease</th>
								<th>Action</th>
							</tr>
						</thead>
						</tbody>
						<?php
							$query = "SELECT * from pesticide";
							$result = mysqli_query($db, $query);
							$count = $result->num_rows;
							if ($count > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()){
								?>
								<tr>
									<td><?php echo $row["pest_id"]?></td>
									<td><?php echo $row["pest_name"]?></td>
									<td><?php echo $row["disease_name"]?></td>
									<td><button type="button" class="btn btn-danger deletebtn" data-column="pest_id" data-table="pesticide" data-id="<?php echo $row["pest_id"]?>">Add crop</button></td>
								</tr>
								<?php
								}
							} else {
								echo "<tr><td colspan='4'> No result found</td></tr>";
							}
							//$conn->close();
						?>								
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<h5> Table PLOUGH</h5>
				<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addplo">Add plough</button>
				<div class="table-responsive">
					<table class="table table-bordered">
						<thead>
							<tr>
								<!--<th>#</th>-->
								<th>#</th>
								<th>Name</th>
								<th>Tool</th>
								<th>Action</th>
							</tr>
						</thead>
						</tbody>
						<?php
							$query = "SELECT * from plough";
							$result = mysqli_query($db, $query);
							$count = $result->num_rows;
							if ($count > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()){
								?>
								<tr>
									<td><?php echo $row["plough_id"]?></td>
									<td><?php echo $row["plough_name"]?></td>
									<td><?php echo $row["tool_name"]?></td>
									<td><button type="button" class="btn btn-danger deletebtn" data-column="plough_id" data-table="plough" data-id="<?php echo $row["plough_id"]?>">Add crop</button></td>
								</tr>
								<?php
								}
							} else {
								echo "<tr><td colspan='4'> No result found</td></tr>";
							}
							//$conn->close();
						?>								
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
	<div id="addcrop" class="modal fade" role="dialog">
		<div class="modal-dialog">				
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Add crop</h4>
				</div>
				<div class="modal-body">
					<div class="input-group">
						<input type="text" name="name" id="cropname" placeholder="Name">
					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-success" id="addcrops">Add</button>
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
	<div id="addfert" class="modal fade" role="dialog">
		<div class="modal-dialog">				
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Add Fertilizer</h4>
				</div>
				<div class="modal-body">
					<div class="input-group">
						<input type="text" name="name" id="fertName" placeholder="Name">
					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-success" id="addfertilizer">Add</button>
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
	<div id="addpest" class="modal fade" role="dialog">
		<div class="modal-dialog">				
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Add Pesticide</h4>
				</div>
				<div class="modal-body">
					<div class="input-group">
						<input type="text" name="pestname" id="pestname" placeholder="Name">
						<input type="text" name="disease" id="disease" placeholder="disease">
					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-success" id="addpesticides">Add</button>
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
	<div id="addplo" class="modal fade" role="dialog">
		<div class="modal-dialog">				
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Add Pesticide</h4>
				</div>
				<div class="modal-body">
					<div class="input-group">
						<input type="text" name="name" id="ploughname" placeholder="Name">
						<input type="text" name="name" id="tool" placeholder="Name">
					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-success" id="addplough">Add</button>
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
	<script>
		$(document).ready(function(){			
			//TODO Update User Status
			$('#addcrops').click(function(){
				var name = $("#cropname").val();
				$.ajax({
					type : 'POST', 
					url  : 'operation.php', 
					data : {'functionname':'add_1','name': name, 'table': 'crop'}, 
				}).done(function(data) {
					if(data == 1){
						//TODO Alert here to show success message 
						window.location.href = 'manage.php';
					}
				}).fail(function(error) {
					console.log(error); 
				});
				return false;
			});

			$('#addfertilizer').click(function(){
				var name = $("#fertName").val();
				$.ajax({
					type : 'POST', 
					url  : 'operation.php', 
					data : {'functionname':'add_1','name': name, 'table': 'fertilizer'}, 
				}).done(function(data) {
					if(data == 1){
						//TODO Alert here to show success message 
						window.location.href = 'manage.php';
					}
				}).fail(function(error) {
					console.log(error); 
				});
				return false;
			});

			$('#addpesticides').click(function(){
				var name = $("#pestname").val();
				var disease = $("#disease").val();
				$.ajax({
					type : 'POST', 
					url  : 'operation.php', 
					data : {'functionname':'addpest', 'name': name, 'disease': disease}, 
				}).done(function(data) {
					if(data == 1){
						//TODO Alert here to show success message 
						window.location.href = 'manage.php';
					}
				}).fail(function(error) {
					console.log(error); 
				});
				return false;
			});

			$('#addplough').click(function(){
				var name = $("#ploughname").val();
				var tool = $("#tool").val();
				$.ajax({
					type : 'POST', 
					url  : 'operation.php', 
					data : {'functionname':'addplough', 'name': name, 'tool': tool}, 
				}).done(function(data) {
					if(data == 1){
						//TODO Alert here to show success message 
						window.location.href = 'manage.php';
					}
				}).fail(function(error) {
					console.log(error); 
				});
				return false;
			});

			$('.deletebtn').click(function(){
				var id = $(this).data("id");
				var table = $(this).data("table");
				var column = $(this).data("column");
				$.ajax({
					type : 'POST', 
					url  : 'operation.php', 
					data : {'functionname':'delete', 'id': id, 'table': table, 'column': column}, 
				}).done(function(data) {
					if(data == 1){
						//TODO Alert here to show success message 
						window.location.href = 'manage.php';
					}
				}).fail(function(error) {
					console.log(error); 
				});
				return false;
			});

			
			
		});
	</script>
</body>
</html>