<?php
  include('server.php');
?>
<!DOCTYPE html>
<html>
<head>
  <title>Registration system PHP and MySQL</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
	<nav class="navbar navbar-inverse">
		<div class="container-fluid">
			<div class="navbar-header">
				<a class="navbar-brand" href="#">Agriculture</a>
			</div>
			<ul class="nav navbar-nav">
				<li class="active"><a href="index.php">Home</a></li>
				<li><a href="manage.php">Management</a></li>
			</ul>
		</div>
	</nav>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h5> Table CROP</h5>
				<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addcrop">Add crop</button>
				<div class="table-responsive">
					<table class="table table-bordered">
						<thead>
							<tr>
								<!--<th>#</th>-->
								<th>#</th>
								<th>Name</th>
								<th>Action</th>
							</tr>
						</thead>
						</tbody>
						<?php
							$query = "SELECT * from crop";
							$result = mysqli_query($db, $query);
							$count = $result->num_rows;
							if ($count > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()){
								?>
								<tr>
									<td><?php echo $row["crop_id"]?></td>
									<td><?php echo $row["name"]?></td>
								</tr>
								<?php
								}
							} else {
								echo "<tr><td colspan='2'> No result found</td></tr>";
							}
							//$conn->close();
						?>								
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<h5> Table FERTILIZER</h5>
				<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addfert">Add fertilizer</button>
				<div class="table-responsive">
					<table class="table table-bordered">
						<thead>
							<tr>
								<!--<th>#</th>-->
								<th>#</th>
								<th>Name</th>
								<th>Action</th>
							</tr>
						</thead>
						</tbody>
						<?php
							$query = "SELECT * from fertilizer";
							$result = mysqli_query($db, $query);
							$count = $result->num_rows;
							if ($count > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()){
								?>
								<tr>
									<td><?php echo $row["fert_id"]?></td>
									<td><?php echo $row["name"]?></td>
								</tr>
								<?php
								}
							} else {
								echo "<tr><td colspan='2'> No result found</td></tr>";
							}
							//$conn->close();
						?>								
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<h5> Table PESTICIDE</h5>
				<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addpest">Add pestiside</button>
				<div class="table-responsive">
					<table class="table table-bordered">
						<thead>
							<tr>
								<!--<th>#</th>-->
								<th>#</th>
								<th>Name</th>
								<th>Disease</th>
								<th>Action</th>
							</tr>
						</thead>
						</tbody>
						<?php
							$query = "SELECT * from pesticide";
							$result = mysqli_query($db, $query);
							$count = $result->num_rows;
							if ($count > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()){
								?>
								<tr>
									<td><?php echo $row["pest_id"]?></td>
									<td><?php echo $row["pest_name"]?></td>
									<td><?php echo $row["disease_name"]?></td>
								</tr>
								<?php
								}
							} else {
								echo "<tr><td colspan='3'> No result found</td></tr>";
							}
							//$conn->close();
						?>								
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<h5> Table PLOUGH</h5>
				<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addplo">Add plough</button>
				<div class="table-responsive">
					<table class="table table-bordered">
						<thead>
							<tr>
								<!--<th>#</th>-->
								<th>#</th>
								<th>Name</th>
								<th>Tool</th>
								<th>Action</th>
							</tr>
						</thead>
						</tbody>
						<?php
							$query = "SELECT * from plough";
							$result = mysqli_query($db, $query);
							$count = $result->num_rows;
							if ($count > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()){
								?>
								<tr>
									<td><?php echo $row["plough_id"]?></td>
									<td><?php echo $row["plough_name"]?></td>
									<td><?php echo $row["tool_name"]?></td>
								</tr>
								<?php
								}
							} else {
								echo "<tr><td colspan='3'> No result found</td></tr>";
							}
							//$conn->close();
						?>								
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</body>
</html>