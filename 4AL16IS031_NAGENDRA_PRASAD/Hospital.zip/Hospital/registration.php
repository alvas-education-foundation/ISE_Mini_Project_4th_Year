
<!doctype html>
<html>
<head>
<meta charset="utf-8"><title><b>HOSPITAL MANAGEMENT SYSTEM</b></title>
	
</head>
<style>
	body
 {
		width: 100%;
		height: 100%;
		font-family: 'Open Sans',sans serif;
		background: #fff;
	}
	
	.registration {
		position: absolute;
		top: 65%;
		left: 50%;
		margin: -200px 0 0 -200px;
		width: 400px;
		height: 300px;
		
		
	}
	input {
		width: 100%;
		margin-bottom: 10px;
		background: rgba(0,0,0,0.3);
		border: none;
		outline: none;
		padding: 10px;
		font-size: 18px;
		color: #000;
		border: 1px solid rgba(0,0,0,0.3);
		border-radius: 4px;
		
	}
	input:focus { box-shadow: inset 0 -5px 45px rgba(100,100,100,0.4),0 1px 1px rgba(255,255,255,0.2);}
	button {
	color: black;
	padding: 14px 24px;
	margin: 8px 0;
	border: none;
	width: 35%;
		font-size: 15px;
		background-color: antiquewhite;
	}
	
   body {
	height: 100%;
	width: 100%;
	background-image: url(826920-amazing-hospital-wallpapers-3000x2000.jpg);
	background-repeat: no-repeat;
	background-size: cover;
	}
  
	
	</style>
	<body>
	<header>
		<div class="top" align="center">
			<h1><b>HOSPITAL MANAGEMENT SYSTEM</b></h1>
		</div>
		</header>


<div class="registration">
<h2><b>Registration</b></h2>
	<form method="post" action="reg.php"> 
		<input type="text" name="username" placeholder="Username" id="uid" />
		<input type="password" name="password" placeholder="Password" id="pswrd" />
		<input type="text" name="email" placeholder="Email" id="email" />
		<button type="submit" action="reg.php"><b>Register</b></button>
			
		
	</form>
</div>
</body>
</html>
