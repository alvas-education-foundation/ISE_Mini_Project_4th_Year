<?php

$conn = mysqli_connect('localhost','root','','hospital');
if(mysqli_connect_errno($conn))
	echo 'Failed Connection';

$pid=$_POST['pid'];
$address=$_POST['address'];
$opname=$_POST['opname'];
$mobile=$_POST['mobile'];
$disease=$_POST['disease'];
$date=$_POST['date'];

$sql = "insert into outpatient values('$pid','$opname','$date','$address','$mobile','$disease')";

$result = mysqli_query($conn,$sql);
if(!$result)
	echo 'Error Insertion';
else 
	echo 'New record created successfully';  
?>
<html>
<body>
<br>
<a href="outpatient.php"><b>BACK</b></a>
</body>
</html>	