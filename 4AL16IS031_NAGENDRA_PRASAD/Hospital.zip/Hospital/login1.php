
<?php
if (Empty($_POST['username'])) {                                                                           //for storing new user into datbase
echo "Empty Field UserName! ...  <a href=registration.php><b>Try again</a> ";exit;}
elseif (Empty($_POST['password'])) {
echo "Empty Field PassWord! ...  <a href=registration.php><b>Try again</a> ";exit;}
elseif(is_numeric($_POST['username'])){
echo "<b>Accepts only Letters for UserName!! .... <a href=registration.php><b>Try again</a> ";exit;}
elseif (strlen($_POST['password']) < 6) {
echo "<b>Too short for your Password!! .... <a href=registration.php><b>Try again</a><br>";exit;}
elseif (($_POST['password']) <> ($_POST['password2'])) {
 echo "<b>Password did not match!! .... <a href=registration.php><b>Try again</a>";exit;}

?>

<?php 

$server = "localhost";	
$database = "hospital";	
$db_user = "root";	
$db_pass = "";	
$table = "registration";

$link = mysqli_connect("localhost","root","",'hospital')
or die ("Could not connect to mysql because ");

$check = "select id from $table where username = '".$_POST['username']."';"; 
$qry = mysqli_query($link,$check)
or die ("Could not match data because ");
$num_rows = mysqli_num_rows($qry); 

if ($num_rows != 0) { 
echo "<b>Sorry,  the username $username is already taken.<br>";
echo "<a href=registration.php><b>Try again</a>";
exit; 
} else {


$insert = mysqli_query($link,"insert into $table values ('NULL', '".$_POST['username']."', '".$_POST['password']."')")
or die("Could not insert data because ");


		}

echo '<span style="color:#000000;text-align:center;"><b>Your user account has been created!<br></span>';
echo '<p style="color: red; text-align: center">
      <b><a href=index.html>log in</a>
      </p>';




