
<?php

$conn= mysqli_connect('localhost','root','','hospital');
if(mysqli_connect_errno($conn))
     echo 'Failed Connection';

$query = "SELECT * FROM inpatient;";
$retval = mysqli_query( $conn, $query);
if(! $query )
{
  die('Could not get data: ' . mysqli_errno());
} 
?>


  <?php

if ($retval->num_rows > 0) {
    echo "<table align=center border=2><tr><th>PatientID  </th><th>Full Name  </th><th>Room_no  </th><th>Date_Of_Discharge </th><th>Address </th><th>Mobile </th><th>Date_Of_Admission </th><th>Advance </th><th>Blood group </th></tr>";
     
    while($row = $retval->fetch_assoc()) {
     echo "<tr><td>".$row["Patient_id"]."</td><td>".$row["Fullname"]."</td><td>".$row["Room_no"]."</td><td>".$row["Dod"]."</td><td>".$row["Address"]."</td><td>".$row["Mobile"]."</td><td>".$row["Doa"]."</td><td>".$row["Advance"]."</td><td>".$row["Bloodgroup"]."</td></tr>";
	
    }
   echo "</table>";
}

 else {
    echo "0 results";
} 
  
   ?>    
<html>
<body>
<style>
body {
	height: 100%;
	width: 100%;
	background-image: url(rawpixel-593598-unsplash.jpg);
	background-repeat: no-repeat;
	background-size: cover;
	}
</style>
<br>
<a href="menu.php"><b>BACK</b></a>
</body>
</html>

