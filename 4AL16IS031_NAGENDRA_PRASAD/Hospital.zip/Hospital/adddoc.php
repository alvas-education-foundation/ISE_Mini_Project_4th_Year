<?php

$conn= mysqli_connect('localhost','root','','hospital');
 if(mysqli_connect_errno($conn))
	echo 'Failed Connection';

$did=$_POST['did'];
$dname=$_POST['dname'];
$mobile=$_POST['mobile'];
$address=$_POST['address'];
$qualification=$_POST['qualification'];
$timing=$_POST['timing'];
$workdays=$_POST['workdays'];
$dob=$_POST['dob'];
$spl=$_POST['spl'];

$sql="insert into doctorinfo values('$did','$dname','$mobile','$address','$qualification','$timing','$workdays','$dob','$spl')";
$result = mysqli_query($conn,$sql);
if(!$result)
	echo 'Error Insertion';
else 
	echo 'New record created successfully';  

?>
<html>
<body>
<br>
<a href="doctor.php"><b>BACK</b></a>
</body></html>

