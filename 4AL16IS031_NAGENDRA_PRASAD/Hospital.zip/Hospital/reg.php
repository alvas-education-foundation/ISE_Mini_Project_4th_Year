<?php
if (Empty($_POST['username'])) {                                                                           //for storing new user into datbase
echo "Empty Field UserName! ...  <a href=registration.php><b>Try again</a> ";exit;}
elseif (Empty($_POST['password'])) {
echo "Empty Field PassWord! ...  <a href=registration.php><b>Try again</a> ";exit;}
elseif(is_numeric($_POST['username'])){
echo "<b>Accepts only Letters for UserName!! .... <a href=registration.php><b>Try again</a> ";exit;}
elseif (strlen($_POST['password']) < 6) {
echo "<b>Too short for your Password!! .... <a href=registration.php><b>Try again</a><br>";exit;}

?>

<?php

$conn= mysqli_connect('localhost','root','','hospital');
if(mysqli_connect_errno($conn))
     echo 'Failed Connection';

$username=$_POST['username'];
$password=$_POST['password'];
$email_id=$_POST['email'];
$sql="insert into registration values('$username','$password','$email_id')";
$result = mysqli_query($conn,$sql);
if(!$result)
	echo 'Error Insertion';
else 
	echo 'Successfully registered';  

?>
<html>
<body>
<br>
<a href="login2.php"><b>BACK</b></a>
</body>
</html>