<?php

$conn= mysqli_connect('localhost','root','','hospital');
if(mysqli_connect_errno($conn))
     echo 'Failed Connection';

$rno=$_POST['rno'];
$rtype=$_POST['rtype'];
$status=$_POST['status'];
$sql="insert into room values('$rno','$rtype','$status')";
$result = mysqli_query($conn,$sql);
if(!$result)
	echo 'Error Insertion';
else 
	echo 'Successfully registered';  

?>
<html>
<body>
<br>
<a href="room.php"><b>BACK</b></a>
</body></html>