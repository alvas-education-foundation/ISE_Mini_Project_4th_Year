
<?php

$conn= mysqli_connect('localhost','root','','hospital');
if(mysqli_connect_errno($conn))
     echo 'Failed Connection';

$query = "SELECT * FROM doctorinfo;";
$retval = mysqli_query( $conn, $query);
if(! $query )
{
  die('Could not get data: ' . mysqli_errno());
} 
?>


  <?php

if ($retval->num_rows > 0) {
    echo "<table align=center border=2><tr><th>DoctorID  </th><th>Full Name  </th><th>Mobile </th><th>Address </th><th>Qualifiction </th><th>Timing </th><th>Work days</th><th>Date_Of_Birth</th><th>Specialization</th></tr>";
     
    while($row = $retval->fetch_assoc()) {
     echo "<tr><td>".$row["Doctor_id"]."</td><td>".$row["Fullname"]."</td><td>".$row["Mobile"]."</td><td>".$row["Address"]."</td><td>".$row["Qualification"]."</td><td>".$row["Timing"]."</td><td>".$row["Workdays"]."</td><td>".$row["Dob"]."</td><td>".$row["Specialization"]."</td></tr>";
	
    }
   echo "</table>";
}

 else {
    echo "0 results";
} 
  
   ?>    
<html>
<body>
<style>
body {
	height: 100%;
	width: 100%;
	background-image: url(doctor_info.jpg);
	background-repeat: no-repeat;
	background-size: cover;
	}
</style>
<br>
<a href="menu.php"><b>BACK</b></a>
</body>
</html>

