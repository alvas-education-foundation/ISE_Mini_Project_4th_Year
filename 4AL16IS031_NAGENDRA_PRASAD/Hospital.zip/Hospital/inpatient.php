
<!doctype html>
<html>
	<body>
		   <style>    
input {
    display: block;
    width: 200px;
    padding: 10px;
    margin-bottom: 10px;
    background-color: #fff;
}
section{
	float: right;
	padding: 10px;
}		   
h2 {
    margin: -5px 0 12px 0;
    margin-left: 400px;
    min-height: 10px;
} 

body {
	height: 100%;
	width: 100%;
	background-image: url(rawpixel-593598-unsplash.jpg);
	background-repeat: no-repeat;
	background-size: cover;
	}

.imgcontainer {
		text-align: center;
		margin: 5px 0 12px 0;
	}
	
	img.hms {
		width: 15%;
		border-radius: 10;
	}


	</style>
	 <header>
    <div class="top" align="center">
		<h1><marquee><i>A Unit Of Compassion + Healthcare</i></marquee></h1>
    </div>
</header>
  
<div class="imgcontainer">
		<img src=""
		alt="" class="hms">
		</div>

  <form method="post" action="add.php" >
    <br> 
   <h1>INPATIENT DETAILS:</h1>
  <br>
  <h2>
  <table>
   <tr> 
   <td>Patient ID : <input name="pid" type="text"> </td>
<td>Full Name : <input name="pname" type="text"></td>
<td>Address :<input name="address"> </td></tr>
 <tr>  <td> Mobile :<input name="mobile" type="text"></td>
  <td>Room No :<input name="rno" type="text"></td>
<td> Date_Of_Admission :<input name="doa" type="text"></td></tr>
      <tr><td>Date_Of_Discharge :<input name="dod" type="text"></td>
          <td>Advance :<input name="advance" type="text"></td>
  <td>Blood group:<input name="bloodgroup" type="text"></td></tr>
  </table>
  <form method="post" action="add.php" name="ADD">
  <input name="submit" value="ADD" type="submit">
</form>
  <form method="post" action="viewinpatient.php" name="VIEW DETAILS">
  <input name="submit" value="VIEW DETAILS" type="submit"><br>
    </form>
  </h2>
        </form>
</body>
</html>
