
<!doctype html>
<html>
<body>
<style>    
input {
    display: block;
    width: 200px;
    padding: 10px;
    margin-bottom: 10px;
    background-color: #fff;
}

section{
	float: right;
	padding: 10px;

}		
 
h2 {
    margin: -5px 0 12px 0;
    margin-left: 400px;
    min-height: 10px;
} 

body {
	height: 100%;
	width: 100%;
	background-image: url(rawpixel-593598-unsplash.jpg);
	background-repeat: no-repeat;
	background-size: cover;
	}

.imgcontainer {
		text-align: center;
		margin: 5px 0 0px 0;
	}
	
	img.hms {
		width: 15%;
		border-radius: 10;
	}
    td{
        color: white;
    }
	</style>

		 <header>
    <div class="top" align="center">
		<h1 style="color:white;"><marquee><i>A Unit Of Compassion + Healthcare</i></marquee></h1>
    </div>
</header>

<div class="imgcontainer">
		<img src=""
		alt="" class="hms">
		</div>

 <form method="post" action = "addp.php">
  <h1 style="color:white;">ADD NEW PATIENT:</h1><center>
  <table>
  <tr>
	  <td>PatientID : <input name="pid" type="text"></td>
           <td>Full Name : <input name="pname" type="text"></td>
	  <td>Address :<input name="address"></td></tr>
	 <tr><td>Date_Of_Admission :<input name="doa" type="date"></td>
	  <td>Sex :<input name="sex" type="text"></td>
		  <td>Disease :<input name="disease" type="text"></td></tr>
			  <tr><td>Age :<input name="age" type="text"></td>
			  <td> Date_Of_Birth :<input name="dob" type="date"></td>
			  <td>Mobile :<input name="mobile" type="text"></td></tr>
		         <tr> <td>Doctor_id:<input name="did" type="text"></td>
              <td>Blood group:<input name="bloodgroup" type="text"></td></tr> 
  </table></center>
  <form method="post" action="addp.php" name="ADD">
  <input name="submit" value="ADD" type="submit"style="margin-left:280px;">
  </form>
<form method="post" action="viewpatient.php" name="VIEW DETAILS">
<input name="submit" value="VIEW DETAILS" type="submit" style="margin-left:280px;">
      </form>
    </form>
</body>
</html>

   
