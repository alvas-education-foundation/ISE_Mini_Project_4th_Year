
<?php
ob_start();


$server = "localhost";	  
$database = "hospital";  
$db_user = "root";	  
$db_pass = "";	         
$table = "registration";	

$link = mysqli_connect($server, $db_user, $db_pass,$database)
or die ("Could not connect to mysql because ".mysqli_error()); 

$match = "select * from $table where Username = '".$_POST['username']."' 
and Password = '".$_POST['password']."';"; 

$qry = mysqli_query($link,$match) 
or die ("Could not match data because". mysqli_error($link)); 
?>
<html>
<body>
<?php
$num_rows = mysqli_num_rows($qry); 
if ($num_rows <= 0) { 

		
echo  '<span style="color:#000000;text-align:center;"><b>Sorry, there is no username with the specified password.<br></span>'; 
?>
<br>
<a href="login2.php"><b>Try Again</b></a>

<?php
exit;
}
else echo 'Login Sucessful';
?>

<br>
<a href ="menu.php"><b> PROCEED</b></a>
</body>
</html>
<?php
ob_end_flush();
?> 