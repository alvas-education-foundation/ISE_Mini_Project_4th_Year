
<!doctype html>
<html>

	<body>
		   <style>    
input {
    display: block;
    width: 200px;
    padding: 10px;
    margin-bottom: 10px;
    background-color: #fff;
}
section{
	float: right;
	padding: 10px;
}		   
h2 {
    margin: -5px 0 12px 0;
    margin-left: 400px;
    min-height: 580px;
} 

body {
	height: 100%;
	width: 100%;
	background-image: url(ITimprovingHealthcare.jpg);
	background-repeat: no-repeat;
	background-size: cover;
	}

.imgcontainer {
		text-align: center;
		margin: 5px 0 12px 0;
	}


	img.hms {
		width: 15%;
		border-radius: 10;
			   }


	</style>
	 <header>
    <div class="top" align="center">
		<h1><marquee><I>A Unit Of Compassion + Healthcare</I></marquee></h1>
    </div>
</header>
        	<div class="imgcontainer">
		<img src=""
		alt="" class="hms">
		</div>

        <form method="post" action="add3.php" >
    <br> <h1>STAFF DETAILS:</h1>
	  <br>
<h2>
<table>
	  <tr> 
   <td>Staff ID : <input name="sid" type="text"> </td>
<td>Full Name : <input name="sname" type="text"> </td>
<td>Phone :<input name="phone" type="text"></td></tr>
  <tr> <td> Salary :<input name="salary" type="text"></td>
  <td>Sex :<input name="sex" type="text"></td>
<td> Address :<input name="address" type="text"></td></tr>
	  <tr><td>Position :<input name="position" type="text"></td>
<td>Qualification :<input name="qualification" type="text"></td></tr>
  </table>
  <form method="post" action="add3.php" name="ADD">
  <input name="submit" value="ADD" type="submit">
  </form>
  <form method="post" action="viewstaff.php" name="VIEW DETAILS">
  <input name="submit" value="VIEW DETAILS" type="submit"><br>
    </form>
	  </h2>
        </form>
</body>
</html>
