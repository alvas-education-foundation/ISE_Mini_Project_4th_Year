<?php

$conn= mysqli_connect('localhost','root','','hospital');
if(mysqli_connect_errno($conn))
     echo 'Failed Connection';

$pid=$_POST['pid'];
$pname=$_POST['pname'];
$address=$_POST['address'];
$age=$_POST['age'];
$mobile=$_POST['mobile'];
$sex=$_POST['sex'];
$dob=$_POST['dob'];
$doa=$_POST['doa'];
$bloodgroup=$_POST['bloodgroup'];
$did=$_POST['did'];
$disease=$_POST['disease'];


$sql="insert into patientreg values('$pid','$pname','$sex','$age','$mobile','$address','$doa','$disease','$dob','$bloodgroup','$did')";
$result = mysqli_query($conn,$sql);
if(!$result)
	echo 'Error Insertion';
else 
	echo 'New record created successfully';  

?>
<html>
<body>
<br>
<a href="patient_reg.php"><b>BACK</b></a>
</body>
</html>


	
