
<!doctype html>
<html>
	
	<body>
		   <style>    

input {
    display: block;
    width: 200px;
    padding: 10px;
    margin-bottom: 10px;
    background-color: #ffffff;
}
section{
	float: right;
	padding: 10px;
      }
h2 {
    margin: -5px 0 12px 0;
    margin-left: 400px;
     min-height: 580px; 
    
}

body {
	height: 100%;
	width: 100%;
	background-image: url(1.jpg);
	background-repeat: no-repeat;
	background-size: cover;
	}

.imgcontainer {
		text-align: center;
		margin: 5px 0 0 0;
	}


	img.hms {
		width: 15%;
		border-radius: 10;
			   }
               td{
                   color:white;
               }
		</style>

		 <header>
		 		
    <div class="top" align="center">
		<h1><marquee><I>A Unit Of Compassion + Healthcare</I></marquee></h1>
    </div>
</header>

        <form method="post" action="add1.php" >
    <br>
  <h1 style="color:black;">ROOM DETAILS:</h1>
  <br>
  <h2>
  <table>
   <tr> 
   <td style="color:black;">Room No : <input name="rno" type="text"> </td>
<td style="color:black;">Room Type :<input name="rtype" type="text" > </td>
	   <td style="color:black;">Status : <input name="status" type="text"> </td></tr>
  </table>
  <form method="post" action="add1.php" name="ADD">
  <input name="submit" value="ADD" type="submit">
</form>
  <form method="post" action="viewroom.php" name="VIEW DETAILS">
  <input name="submit" value="VIEW DETAILS" type="submit"><br>
    </form>
            </h2>
      </form>
			   
			   </body>
			   </html>