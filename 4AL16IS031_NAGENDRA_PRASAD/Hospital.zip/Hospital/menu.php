
<!doctype html>
<html>               
<body>
<style>
	input{
		display: block;
		width: 200px;
		padding: 10px;
		margin-bottom: 10px;
		margin-left: 525px;
	}

	section{
		float: center;
		padding: 30px;	
	}
          
body {
	height: 100%;
	width: 100%;
	background-image: url(826888-hospital-wallpapers-1920x1080-for-mac.jpg);
	background-repeat: no-repeat;
	background-size: cover;
	}

	</style>
    <header>
	<div class="top" align="center">
		<h1><marquee><i>A Unit Of Compassion + Healthcare</i></marquee></h1>
	</div>
   </header>
	
		<h1 align="center">MENU</h1>

  <form method="post" action="patient_reg.php" name="patientreg">
  <input name="patientreg" value="PATIENT REGISTERATION" type="submit"></form>

 <form method="post" action="inpatient.php" name="patientchkout">
  <input name="patientchkout" value="INPATIENT" type="submit"></form>
  
   <form method="post" action="outpatient.php" name="outpatient">
  <input name="outpatient" value="OUTPATIENT" type="submit"></form> 
  
  <form method="post" action="doctor.php" name="doctorinfo">
  <input name="doctorinfo" value="DOCTOR INFORMATION" type="submit"></form>

  <form method="post" action="staffinfo.php" name="staffinfo">
  <input name="staffinfo" value="STAFF INFORMATION" type="submit"></form>
  
  <form method="post" action="room.php" name="room">
  <input name="room" value="ROOM" type="submit"></form>
  
  <form method="post" action="logout.php" name="logout">
  <input name="logout" value="LOGOUT" type="submit"></form>

</body>
</html>
