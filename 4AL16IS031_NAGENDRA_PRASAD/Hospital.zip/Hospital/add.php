<?php

$conn = mysqli_connect('localhost','root','','hospital');
if(mysqli_connect_errno($conn))
	echo 'Failed Connection';

$pid=$_POST['pid'];
$pname=$_POST['pname'];
$address=$_POST['address'];
$mobile=$_POST['mobile'];
$doa=$_POST['doa'];
$dod=$_POST['dod'];
$advance=$_POST['advance'];
$rno=$_POST['rno']; 
$bloodgroup=$_POST['bloodgroup'];

$sql = "insert into inpatient values('$pid','$pname','$rno','$dod','$address','$mobile','$doa','$advance','$bloodgroup')";
$result = mysqli_query($conn,$sql);
if(!$result)
	echo 'Error Insertion';
else 
	echo 'New record created successfully';  
?>
<html>
<body>
<br>
<a href="inpatient.php"><b>BACK</b></a>
</body>
</html>	
