<!doctype html>
<html>
<head>
<meta charset="utf-8">
	<title><b>HOSPITAL MANAGEMENT SYSTEM</b></title>
	
</head>
<style>
	body {
		width: 100%;
		height: 100%;
		font-family: 'Open Sans',sans serif;
		background: #fff;
	}
	.login {
		position: absolute;
		top: 65%;
		left: 50%;
		margin: -150px 0 0 -150px;
		width: 350px;
		height: 300px;
		
	}
	.login h1 {
		 color: #000; letter-spacing: 1px; text-align: center; 
	}
	.registration {
		position: absolute;
		top: 65%;
		left: 50%;
		margin: -130px 0 0 -130px;
		width: 400px;
		height: 300px;
		
		
	}
	input {
		width: 100%;
		margin-bottom: 10px;
		background: rgba(0,0,0,0.3);
		border: none;
		outline: none;
		padding: 10px;
		font-size: 18px;
		color: #000;
		border: 1px solid rgba(0,0,0,0.3);
		border-radius: 4px;
		
	}
	input:focus { box-shadow: inset 0 -5px 45px rgba(100,100,100,0.4),0 1px 1px rgba(255,255,255,0.2);}
	button {
	color: black;
	padding: 14px 24px;
	margin: 8px 0;
	border: none;
	width: 35%;
		font-size: 15px;
		background-color: antiquewhite;
	}

	.imgcontainer {
		text-align: center;
		margin: 24px 0 12px 0;
	}
	
	img.hms {
		width: 10%;
		border-radius: 10;
	}
	
 body {
	height: 100%;
	width: 100%;
	background-image: url(logout.jpg);
	background-repeat: no-repeat;
	background-size: cover;
	}
  
	
	</style>
	<body>
	<header>
		<div class="top" align="center">
			<h1><b>HOSPITAL MANAGEMENT SYSTEM</b></h1>
		</div>
		</header>
		<div class="imgcontainer">
		</div>

<div class="login">
<h2><b>Login</b></h2>
	<form  action="register.php" method="post"> 
		<input type="text" name="username" placeholder="Username" id="uid" />
		<input type="password"  name="password" placeholder="Password" id="pswrd" />
		<input type="submit" class="loginbtn" value="Login">
	         
	<a href="registration.php">	<input type="button" id="submit_btn" value="REGISTER"></a>
			
		
	</form>
</div>
</body>
</html>
