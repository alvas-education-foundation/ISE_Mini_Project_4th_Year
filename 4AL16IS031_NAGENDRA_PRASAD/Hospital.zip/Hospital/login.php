<?php
$username = $_POST['Username'];
$password = $_POST['Password'];

//$username = stripcslashes($username);

//$password = stripcslashes($password);
//$username = mysql_real_escape_string($username);
//$password = mysql_real_escape_string($password);



 $db = mysqli_connect('MySQL57','localhost','root','hospital')
	 echo "connected";
 or die('Error connecting to MySQL server.');

$result = mysqli_query($db,"SELECT * FROM login WHERE username = '$Username' AND password = '$Password'")
or die("Failed to querry database".mysqli_errno());


$row=mysqli_fetch_array($result);

if ($row['username'] == $Username && $row['password'] == $Password) {
	//echo "login successfull";
	header("location:login.html");
} else {
	echo "FAILED TO LOGIN";
}

 
?>
