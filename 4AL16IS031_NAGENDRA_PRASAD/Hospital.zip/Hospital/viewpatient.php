
<?php

$conn= mysqli_connect('localhost','root','','hospital');
if(mysqli_connect_errno($conn))
     echo 'Failed Connection';

$query = "CALL proc();";
$retval = mysqli_query( $conn, $query);
if(! $query )
{
  die('Could not get data: ' . mysqli_errno());
} 
?>


  <?php

if ($retval->num_rows > 0) {
    echo "<table align=center border=2><tr><th>PatientID  </th><th>Full Name  </th><th>Sex  </th><th>Age  </th><th>Mobile  </th><th>Address </th><th>Date_Of_Admission </th><th>Disease </th><th>Date_Of_Birth </th><th>Blood group </th><th>Doctor_id </th></tr>";
     
    while($row = $retval->fetch_assoc()) {
     echo "<tr><td>".$row["Patient_id"]."</td><td>".$row["Fullname"]."</td><td>".$row["Sex"]."</td><td>".$row["Age"]."</td><td>".$row["Mobile"]."</td><td>".$row["Address"]."</td><td>".$row["Doa"]."</td><td>".$row["Disease"]."</td><td>".$row["Dob"]."</td><td>".$row["Bloodgroup"]."</td><td>".$row["Doctor_id"]."</td></tr>";
	
    }
   echo "</table>";
}

 else {
    echo "0 results";
} 
  
   ?>    
<html>
<body>
<style>
body {
	height: 100%;
	width: 100%;
	background-image: url(rawpixel-593598-unsplash.jpg);
	background-repeat: no-repeat;
	background-size: cover;
	}
</style>
<br>
<a href="menu.php"><b>BACK</b></a>
</body>
</html>

