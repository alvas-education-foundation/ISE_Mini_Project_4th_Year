
<!doctype html>
<html>
	
	<body style="background-color: #fff;">
		   <style>    
input {
    display: block;
    width: 200px;
    padding: 10px;
    margin-bottom: 10px;
    background-color: #fff;
}
section{
	float: right;
	padding: 10px;

}		   
h2 {
    margin-left: 400px;
    min-height: 10px;
    
} 

body {
	height: 100%;
	width: 100%;
	background-image: url(doctor_info.jpg);
	background-repeat: no-repeat;
	background-size: cover;
	}
 
.imgcontainer {
		text-align: center;
		margin: 24px 0 12px 0;
	}
	
	img.hms {
		width: 15%;
		border-radius: 10;
	}
	
	</style>

		 <header>
    <div class="top" align="center">
		<h1><marquee><i>A Unit Of Compassion + Healthcare</i></marquee></h1>
    </div>
</header>

  <form method="post" action="adddoc.php" >
    <br>
  <h1>DOCTOR DETAILS:</h1>
  <br>
<h2>
  <table>
   <tr> 
   <td>Doctor id : <input name="did" type="text"> </td>
<td>Full Name : <input name="dname" type="text"> </td>
<td>Address :<input name="address"></td></tr>
  <tr> <td> Date_Of_Birth :<input name="dob" type="text"></td>
  <td>Mobile :<input name="mobile" type="text"></td>
<td> Specialization:<input name="spl" type="text"></td></tr>
<tr><td> Qualification:<input name="qualification" type="text"></td>
    <td>Timing:<input name="timing" type="text"></td>
    <td>Work days:<input name="workdays" type="text"></td></tr>
  </table>

  <form method="post" action="adddoc.php" name="ADD">
  <input name="submit" value="ADD" type="submit">
</form>
  <form method="post" action="viewdoctor.php" name="VIEW DETAILS">
  <input name="submit" value="VIEW DETAILS" type="submit"><br>
	  </form>
	</h2>
        </form>
</body>
</html>
