
<?php

$conn= mysqli_connect('localhost','root','','hospital');
if(mysqli_connect_errno($conn))
     echo 'Failed Connection';

$query = "SELECT * FROM room";
$retval = mysqli_query( $conn, $query);
if(! $query )
{
  die('Could not get data: ' . mysqli_errno());
} 
?>


  <?php

if ($retval->num_rows > 0) {
    echo "<table align=center border=2><tr><th>RoomNo  </th><th>Room type  </th><th>Status  </th></tr>";
     
    while($row = $retval->fetch_assoc()) {
     echo "<tr><td>".$row["rno"]."</td><td>".$row["rtype"]."</td><td>".$row["status"]."</td></tr>";
	
    }
   echo "</table>";
}

 else {
    echo "0 results";
} 
  
   ?>    
<html>
<body>
<style>
body {
	height: 100%;
	width: 100%;
	background-image: url(1.jpg);
	background-repeat: no-repeat;
	background-size: cover;
	}
</style>
<br>
<a href="menu.php"><b>BACK</b></a>
</body>
</html>

