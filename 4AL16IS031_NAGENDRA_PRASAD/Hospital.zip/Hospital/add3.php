<?php

$conn = mysqli_connect('localhost','root','','hospital');
if(mysqli_connect_errno($conn))
	echo 'Failed Connection';

$Staff_id=$_POST['sid'];
$Phone=$_POST['phone'];
$Fullname=$_POST['sname'];
$Salary=$_POST['salary'];
$Sex=$_POST['sex'];
$Address=$_POST['address'];
$Position=$_POST['position'];
$Qualification=$_POST['qualification'];

$sql = "insert into staffinfo values('$Staff_id','$Fullname','$Sex','$Qualification','$Position','$Phone','$Salary','$Address')";

$result = mysqli_query($conn,$sql);
if(!$result)
	echo 'Error Insertion';
else 
	echo 'New record created successfully';  
?>
<html>
<body>
<br>
<a href="staffinfo.php"><b>BACK</b></a>
</body>
</html>	