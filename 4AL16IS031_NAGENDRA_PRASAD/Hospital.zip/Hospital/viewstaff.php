
<?php

$conn= mysqli_connect('localhost','root','','hospital');
if(mysqli_connect_errno($conn))
     echo 'Failed Connection';

$query = "SELECT * FROM staffinfo;";
$retval = mysqli_query( $conn, $query);
if(! $query )
{
  die('Could not get data: ' . mysqli_errno());
} 
?>


  <?php

if ($retval->num_rows > 0) {
    echo "<table align=center border=2><tr><th>StaffID  </th><th>Full Name    </th><th>Sex    </th><th>Qualification   </th><th>Position   </th><th>Phone   </th><th>Salary   </th><th>Address   </th></tr>";
     
    while($row = $retval->fetch_assoc()) {
     echo "<tr><td>".$row["Staff_id"]."</td><td>".$row["Fullname"]."</td><td>".$row["Sex"]."</td><td>".$row["Qualification"]."</td><td>".$row["Position"]."</td><td>".$row["Phone"]."</td><td>".$row["Salary"]."</td><td>".$row["Address"]."</td></tr>";
	
    }
   echo "</table>";
}

 else {
    echo "0 results";
} 
  
   ?>    
<html>
<body>
<style>
body {
	height: 100%;
	width: 100%;
	background-image: url(ITimprovingHealthcare.jpg);
	background-repeat: no-repeat;
	background-size: cover;
	}
</style>
<br>
<a href="menu.php"><b>BACK</b></a>
</body>
</html>

