package Main;

import com.sun.glass.ui.Application;

import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ttt{


public void start(Stage mainstage) throws Exception {

//	Label SuccessMsg=new Label("Saved Successfully");
		//Window=mainstage;
		//Window.setResizable(false);
		Pane root=new Pane();//
		//GridPane BP=new GridPane();
		//HBox HB=new HBox();
		//VBox VB=new VBox();
Canvas canvas=new Canvas(400,300);          //add
//GraphicsContext gc=canvas.getGraphicsContext2D();
//gc.setFill(Color.RED);
StackPane holder=new StackPane();
holder.getChildren().add(canvas);
holder.setStyle("-fx background-color:red");
Scene scene=new Scene(root,200,400);
mainstage.setScene(scene);
mainstage.show();
}

}
