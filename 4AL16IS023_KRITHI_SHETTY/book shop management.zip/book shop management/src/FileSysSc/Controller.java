package FileSysSc;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
//import javafx.scene.image.Image;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.stream.Stream;

import javax.imageio.ImageIO;

import com.sun.prism.Image;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;

/*
 */

public class Controller extends Application {

	// Universal Declarations.
//Image ib=new Image("G:\\grup.jpg");

	Stage Window;
	//ImageView iv1 =new ImageView();

	//iv1.setFitWidth (100);
	//iv1.setImage (image);
	Scene Main,AddFile,SearchWindow,SrcWindow,ShowAll;
	int HashValue;
	String RecFile="F:\\file.txt";
	int confirmation=0;
	String TEMP;
	String Line;
	String T1,T2;
	Label gg=new Label("dd");
	ArrayList<ScContact>StreamLoader=new ArrayList<ScContact>();
	private final TableView<ScContact> tableView = new TableView<>();
	private final ObservableList<ScContact>dataList= FXCollections.observableArrayList();
	TableColumn columnF1;
	TableColumn columnF2;
	TableColumn columnF3;
	TableColumn columnF4;
	TableColumn columnF5;

	public void initTable()
	{
	columnF1 = new TableColumn("STUDENT NAME");
    columnF1.setCellValueFactory(new PropertyValueFactory<>("f1"));
    columnF2 = new TableColumn("STUDENT PHONE NUMBER");
    columnF2.setCellValueFactory(new PropertyValueFactory<>("f2"));
    columnF3 = new TableColumn("ROOM NO");
    columnF3.setCellValueFactory(new PropertyValueFactory<>("f3"));
    columnF4 = new TableColumn("FEE DUE");
    columnF4.setCellValueFactory(new PropertyValueFactory<>("f4"));
    columnF5 = new TableColumn("WARDEN");
    columnF5.setCellValueFactory(new PropertyValueFactory<>("f5"));
    columnF1.prefWidthProperty().bind(tableView.widthProperty().multiply(0.2));
    columnF2.prefWidthProperty().bind(tableView.widthProperty().multiply(0.2));
    columnF3.prefWidthProperty().bind(tableView.widthProperty().multiply(0.2));
    columnF4.prefWidthProperty().bind(tableView.widthProperty().multiply(0.2));
    columnF5.prefWidthProperty().bind(tableView.widthProperty().multiply(0.3));
    tableView.setPrefSize(1000, 300);
	}
	//--------------------------------------------
	public static void main(String[] args) {
		launch(args);
	}
	// Core Functions - Adding the Content to File.
	public int AddtoFile(String Line)
	{
		try {
		 Writer writer = new BufferedWriter(new OutputStreamWriter(
			        new FileOutputStream(RecFile, true), "UTF-8"));
		 HashValue=Line.hashCode();

		 writer.write(Line+"#"+HashValue+"\n");
		writer.close();
		return 1;
		}
		catch(Exception E)
		{
			return 0;
		}
	}
	public void TableViewer() {
       tableView.getItems().clear();
        tableView.setItems(dataList);
        tableView.getColumns().addAll(columnF1, columnF2, columnF3, columnF4,columnF5);
        Button ReTButton=new Button("Return");
        ReTButton.setOnAction(e->{
        	Window.setScene(Main);
        });
        VBox vBox = new VBox();
    	GridPane BPSHA=new GridPane();
        vBox.setSpacing(10);
        vBox.getChildren().add(tableView);
        vBox.getChildren().add(ReTButton);
        readCSV();
        BPSHA.getChildren().add(vBox);
        ShowAll=new Scene(BPSHA, 1000,500 );
	}
	// Core Function #2 - Searching the File.
	public String SearchFile(String Item)
	{
		 tableView.getItems().clear();
		try {
			BufferedReader bb=new BufferedReader(new FileReader(RecFile));
			TEMP="";
			while((Line=bb.readLine())!=null)
				{	T1=Item;
				T1=T1.toUpperCase();
				T2=Line;
				T2=T2.toUpperCase();

				if(T2.contains(T1))
				{
					//System.out.println(Line);
					String[] fields = Line.split("#");
	                //System.out.println("ddddd"+fields[4]+"jjjjjjj");
	                ScContact record = new ScContact(fields[0], fields[1], fields[2],fields[3],fields[4],fields[5]);
	                dataList.add(record);
					TEMP=TEMP+"\n"+Line;
				}
			}
			tableView.setItems(dataList);
	        tableView.getColumns().addAll(columnF1, columnF2, columnF3, columnF4,columnF5);
	        Button ReTButton=new Button("Return");
	        ReTButton.setOnAction(e->{
	        	Window.setScene(Main);
	        });
			VBox vBox = new VBox();
	    	GridPane BPSHA=new GridPane();
	        vBox.setSpacing(10);
	        vBox.getChildren().add(tableView);
	        vBox.getChildren().add(ReTButton);
	        BPSHA.getChildren().add(vBox);
	        ShowAll=new Scene(BPSHA, 800,500 );
			if(TEMP.length()>0)
				return TEMP;
			bb.close();
		}
		catch(Exception e)
		{
			System.out.println("Error in File Access");
		}
		return "The Item : "+Item+" not Found in the Contact List";
	}
	//Core Function #3 : Show All Contacts
	public void ShowAllContacts()
	{
		try (Stream<String> stream = Files.lines(Paths.get(RecFile))) {
	        stream.forEach(System.out::println);
	}
		catch( Exception E)
		{
			System.out.println("Error : Cannot Open File");
		}
	}
	// Beginning of Interface.
	@Override
	public void start(Stage mainstage) throws Exception {
		Label SuccessMsg=new Label("Saved Successfully");
			Window=mainstage;
			Window.setResizable(false);
			GridPane BP=new GridPane();
			HBox HB=new HBox();
			VBox VB=new VBox();
		    VBox root = new VBox();

			 HB.setPadding(new Insets(25, 25, 15, 12));
			 HB.setSpacing(10);
			VB.setBackground(new Background(new BackgroundFill(Color.GOLD, CornerRadii.EMPTY, Insets.EMPTY)));
			 VB.setPadding(new Insets(15, 12, 15, 12));
			 VB.setSpacing(10);
			 VB.setAlignment(Pos.CENTER);
			 initTable();
			// Scene 1 - Configuration.
			BP.setBackground(new Background(new BackgroundFill(Color.GOLD, CornerRadii.EMPTY, Insets.EMPTY)));
			BP.setPadding(new Insets(10,10,10,10));
BP.setAlignment(Pos.CENTER);
			// Screen 1 Begins Here.
			Label WelcomeTitle=new Label(" WELCOME TO HOSTEL PAGE");
			WelcomeTitle.setFont(Font.font("Comic", FontWeight.EXTRA_BOLD,FontPosture.ITALIC, 55));
			WelcomeTitle.setTextFill(Color.BLUE);
			Label Heading=new Label("Please Select an Option :");
			Heading.setFont(Font.font("Comic",FontWeight.BLACK,24));
			/*RadioButton rb1=new RadioButton();
			rb1.setText("home");*/
			Button AddC=new Button("ADD A NEW STUDENT");
			AddC.setPrefSize(200,20);
			AddC.setStyle("-fx-background-color:darkorange");
			AddC.setOnAction(e->{
			Window.setScene(AddFile);
			SuccessMsg.setVisible(false);
			});
			Button SearchC=new Button("STUDENT DETAIL");
			SearchC.setPrefSize(200,20);
			SearchC.setStyle("-fx-background-color:darkorange");

			Button SrcC=new Button("SEARCH STUDENT");
			SrcC.setPrefSize(200,20);

			SrcC.setStyle("-fx-background-color:darkorange");

			Button ViewAC=new Button("VIEW ALL THE  STUDENTS");
			ViewAC.setPrefSize(200,20);
			ViewAC.setStyle("-fx-background-color:darkorange");
			ViewAC.setOnAction(e->{
				System.out.println("\nThe Students Currently in the File :\n\n");
				TableViewer();
				Window.setScene(ShowAll);
				//ShowAllContacts();
			});
			SearchC.setOnAction(e->{Window.setScene(SearchWindow);
									System.out.println("Click Registered on Search Button");	});

			SrcC.setOnAction(e->{Window.setScene(SrcWindow);
			System.out.println("Click Registered on Search Button");	});

			HB.getChildren().addAll(WelcomeTitle);
			VB.getChildren().addAll(Heading,AddC,SearchC,SrcC,ViewAC);
//HB.getChildren().add(iv1);
			BP.add(HB,0,1);
			BP.add(VB,0,3);
			Main=new Scene(BP,800,400);
// --------------------------------------------------------------------------------------------
			// Scene 2 : File Name addition Window Begins here.
			GridPane BP1=new GridPane();
			HBox HB1=new HBox();
			HBox HB11=new HBox();
			VBox VB1=new VBox();
			 HB1.setPadding(new Insets(25, 25, 15, 12));
			 HB1.setSpacing(10);
			 HB1.setAlignment(Pos.BOTTOM_RIGHT);
				VB1.setBackground(new Background(new BackgroundFill(Color.GOLD, CornerRadii.EMPTY, Insets.EMPTY)));
			 HB11.setPadding(new Insets(25, 25, 15, 12));
			 HB11.setSpacing(10);HB11.setAlignment(Pos.BOTTOM_RIGHT);
			 VB1.setPadding(new Insets(15, 12, 15, 12));
			 VB1.setSpacing(10);
			 VB1.setAlignment(Pos.CENTER);
			 BP1.setBackground(new Background(new BackgroundFill(Color.GOLD, CornerRadii.EMPTY, Insets.EMPTY)));
			BP1.setPadding(new Insets(10,10,10,10));
BP1.setAlignment(Pos.CENTER);
			SuccessMsg.setFont(Font.font("Verdana",FontWeight.BOLD,15));
			SuccessMsg.setTextFill(Color.GREEN);
			SuccessMsg.setVisible(false);
			Label WelcomeTitle1=new Label("Add A New Student To File");
			WelcomeTitle1.setFont(Font.font("Times New Roman", FontWeight.LIGHT,FontPosture.ITALIC, 44));
			WelcomeTitle1.setTextFill(Color.WHITE);
			Label Heading1=new Label("Please Fill all the Fields :");
			Heading1.setFont(Font.font("Times New Roman",FontWeight.BLACK,24));
			Label FName=new Label("Student Name :");
			FName.setFont(Font.font("times new roman",20));
			TextField FnameF=new TextField();
			FnameF.setPrefSize(40, 40);
			FnameF.setPromptText("Enter Proper Student Name");
			FnameF.setOnMouseClicked(e->SuccessMsg.setVisible(false));
			Label Lname=new Label("Phone Number :");
			Lname.setFont(Font.font("times new roman",20));
			TextField LnameF=new TextField();
			LnameF.setPrefSize(40, 40);
			LnameF.setPromptText("Enter Proper student phone number");
			LnameF.setOnMouseClicked(e->SuccessMsg.setVisible(false));
			Label Phone=new Label("Room No :");
			Phone.setFont(Font.font("times new roman",20));
			TextField PhoneF=new TextField();
			PhoneF.setPrefSize(40, 40);
			PhoneF.setPromptText("Enter 5 digit Room no");
			PhoneF.setOnMouseClicked(e->SuccessMsg.setVisible(false));
			Label Price=new Label("Fees :");
			Price.setFont(Font.font("times new roman",20));
			TextField PriceF=new TextField();
			PriceF.setPrefSize(40, 40);
			PriceF.setPromptText("Enter valid Fees");
			PriceF.setOnMouseClicked(e->SuccessMsg.setVisible(false));
			Label Publisher=new Label("Wardern :");
			Publisher.setFont(Font.font("times new roman",20));
			TextField PublisherF=new TextField();
			PublisherF.setPrefSize(40, 40);
			PublisherF.setPromptText("Enter Wardern");
			PublisherF.setOnMouseClicked(e->SuccessMsg.setVisible(false));
		/*	Label Email=new Label("Price :");
			TextField EmailF=new TextField();
			EmailF.setPromptText("Enter Price");
			EmailF.setOnMouseClicked(e->SuccessMsg.setVisible(false));*/
			Button Save=new Button("ADD A NEW STUDENT");
			Save.setStyle("-fx-background-color:darkorange");
			Save.setPrefSize(200,40);
			Save.setOnAction(e->{
				if((FnameF.getLength()>0)&&(LnameF.getLength()>0)&&(PhoneF.getLength()>0)&&(PriceF.getLength()>0)&&(PublisherF.getLength()>0))
				{
				TEMP=PhoneF.getText();
				System.out.println(TEMP);
				if(TEMP.matches("[0-9]*") && TEMP.length()==5)
				{
					/*TEMP=EmailF.getText();
				if(TEMP.matches("[[0-9]*[a-z]*[0-9]*]+[@][a-z]+[.][a-z]+"))
				{	*/
				confirmation=AddtoFile(FnameF.getText()+"#"+LnameF.getText()+"#"+PhoneF.getText()+"#"+PriceF.getText()+"#"+PublisherF.getText());
				if(confirmation==1)
				{
					System.out.println("Added a new Student");
					SuccessMsg.setText("Successfull Added a New Student");
					SuccessMsg.setTextFill(Color.GREEN);
					SuccessMsg.setVisible(true);
					FnameF.setText("");
					LnameF.setText("");
					PhoneF.setText("");
					PriceF.setText("");
					PublisherF.setText("");
				}
				else
					System.out.println("ERROR - Adding to the File..!");
			/*}else
			{
				SuccessMsg.setText("Enter valid price");
				SuccessMsg.setTextFill(Color.RED);
				SuccessMsg.setVisible(true);
				*/}
				else
				{
					SuccessMsg.setText("ENTER PROPER ROOM NUMBER");
					SuccessMsg.setTextFill(Color.RED);
					SuccessMsg.setVisible(true);
				}
				}
				else
				{
					SuccessMsg.setText("ENTER ALL THE FIELDS");
					SuccessMsg.setTextFill(Color.RED);
					SuccessMsg.setVisible(true);
				}
		});
			Button Cancel=new Button("Return");
			Cancel.setPrefSize(80,40);
			Cancel.setStyle("-fx-background-color:darkorange");
			Cancel.setOnAction(e->{Window.setScene(Main);
									System.out.println("Click Registered on Search Button");
									try {
									Runtime r=Runtime.getRuntime();
									System.out.println(r.exec("uname -a"));
									}
									catch(Exception V)
									{

									}
			});
			HB1.getChildren().addAll(WelcomeTitle1);
			VB1.getChildren().addAll(Heading1,FName,FnameF,Lname,LnameF,Price,PriceF,Phone,PhoneF,Publisher,PublisherF);
			HB11.getChildren().addAll(Save,Cancel,SuccessMsg);
			BP1.add(HB1,0,1);
			BP1.add(VB1,0,3);
			BP1.add(HB11,0,4);
		AddFile=new Scene(BP1,800,600);
// -----------------------------------------------------------------------------------------------

		GridPane BP3=new GridPane();
		HBox HB2=new HBox();
		HBox HB21=new HBox();
		VBox VB2=new VBox();
		BP3.setBackground(new Background(new BackgroundFill(Color.GOLD, CornerRadii.EMPTY, Insets.EMPTY)));
		HB2.setPadding(new Insets(25, 25, 15, 12));
		 HB2.setSpacing(10);
HB2.setAlignment(Pos.CENTER_RIGHT);
		 HB21.setPadding(new Insets(25, 25, 15, 12));
		 HB21.setSpacing(10);
HB21.setAlignment(Pos.CENTER_RIGHT);
VB2.setBackground(new Background(new BackgroundFill(Color.GOLD, CornerRadii.EMPTY, Insets.EMPTY)));
		 VB2.setPadding(new Insets(50, 50, 15, 12));
		 VB2.setSpacing(10);
		 VB2.setAlignment(Pos.CENTER_RIGHT);
		Label SearchTitle=new Label("Enter student name to get phone number: ");
		SearchTitle.setFont(Font.font("Verdana", FontWeight.BOLD,20));
		SearchTitle.setTextFill(Color.RED);
		TextField SearchText=new TextField();
		SearchText.setPromptText("Enter the student name ");
		//SearchText.setPrefSize(30, 5);
		Button SearchNow=new Button("search");
		Button Return=new Button("Return");
		//SearchNow.setPrefSize(25,3);
		SearchNow.setOnAction(e->{
			System.out.println("\nSearch Started\n\n");
			if(SearchText.getText().length()>0)
			{
			SearchFile(SearchText.getText());
			Window.setScene(ShowAll);
			//System.out.println(TEMP);
			}
			else
				SearchText.setPromptText("Enter Something Here First...!");
		});
		Button ReTButton=new Button("Return");

		Return.setOnAction(e->{
			System.out.println("Returning to Home ");
			Window.setScene(Main);

		});
		HB21.getChildren().addAll(SearchNow,Return);
		HB2.getChildren().addAll(SearchTitle);
		VB2.getChildren().addAll(SearchText,HB21);
		BP3.add(HB2, 0, 2);
		BP3.add(VB2, 0,4);
		SearchWindow=new Scene(BP3,800,400);
//---------------------------------------------------------------------------



		GridPane BP4=new GridPane();
		HBox HB4=new HBox();
		HBox HB41=new HBox();
		VBox VB4=new VBox();

		BP4.setBackground(new Background(new BackgroundFill(Color.GOLD, CornerRadii.EMPTY, Insets.EMPTY)));
		HB4.setPadding(new Insets(25, 25, 15, 12));
		 HB4.setSpacing(10);
HB4.setAlignment(Pos.CENTER_RIGHT);
		 HB41.setPadding(new Insets(25, 25, 15, 12));
		 HB41.setSpacing(10);
HB41.setAlignment(Pos.CENTER_RIGHT);
VB4.setBackground(new Background(new BackgroundFill(Color.GOLD, CornerRadii.EMPTY, Insets.EMPTY)));
		 VB4.setPadding(new Insets(50, 50, 15, 12));
		 VB4.setSpacing(10);
		 VB4.setAlignment(Pos.CENTER_RIGHT);
		Label SearchTitle1=new Label("Enter student name to search : ");
		SearchTitle1.setFont(Font.font("Verdana", FontWeight.BOLD,20));
		SearchTitle1.setTextFill(Color.RED);
		TextField SearchText1=new TextField();
		SearchText1.setPromptText("Enter the book name ");
		//SearchText.setPrefSize(30, 5);
		Button SearchNow1=new Button("search");
		Button Return1=new Button("Return");
		//SearchNow.setPrefSize(25,3);
		SearchNow1.setOnAction(e->{
			System.out.println("\nSearch Started\n\n");
			if(SearchText1.getText().length()>0)
			{
			SearchFile(SearchText1.getText());
			Window.setScene(ShowAll);
			//System.out.println(TEMP);
			}
			else
				SearchText1.setPromptText("Enter Something Here First...!");
		});
		Return1.setOnAction(e->{
			System.out.println("Returning to Home ");
			Window.setScene(Main);
		});
		HB41.getChildren().addAll(SearchNow1,Return1);
		HB4.getChildren().addAll(SearchTitle1);
		VB4.getChildren().addAll(SearchText1,HB41);
		BP4.add(HB4, 0, 2);
		BP4.add(VB4, 0,4);
		SrcWindow=new Scene(BP4,800,400);


			Window.setScene(Main);
			Window.setTitle("AIET ISE - File Structure Mini Project");
			Window.show();
	}
	private boolean Validate(String text)
    {
        return text.matches("[0-9]*");
    }
	private void readCSV() {
        String FieldDelimiter = "^";
        dataList.removeAll();
        BufferedReader br;
        try {
            br = new BufferedReader(new FileReader(RecFile));
            String line;
            while ((line = br.readLine()) != null) {
                String[] fields = line.split("#");
                //System.out.println("ddddd"+fields[4]+"jjjjjjj");
                ScContact record = new ScContact(fields[0], fields[1], fields[2],fields[3],fields[4],fields[5]);
                dataList.add(record);
            }
        } catch (FileNotFoundException ex) {
        } catch (IOException ex) {
        }
    }
}
